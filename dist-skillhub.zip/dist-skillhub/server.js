'use strict';
/* ============================================================
   零依赖静态文件服务器（仅用于本地预览）
   ------------------------------------------------------------
   用法：
     node server.js              # 默认 http://localhost:8000
     PORT=9000 node server.js    # 指定端口

   仅监听本机（127.0.0.1），适合本地预览。
   部署到静态托管平台时不需要本文件，直接托管 public/ 目录即可
   （例如 python3 -m http.server $PORT --bind 0.0.0.0 --directory public）。
   ============================================================ */

const http = require('http');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, 'public');
const PORT = Number(process.env.PORT) || 8000;
const HOST = process.env.HOST || '127.0.0.1';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
};

function send(res, status, body, type) {
  res.writeHead(status, {
    'Content-Type': type || 'text/plain; charset=utf-8',
    'Cache-Control': 'no-cache',
  });
  res.end(body);
}

const server = http.createServer(function (req, res) {
  let rel;
  try {
    rel = decodeURIComponent((req.url || '/').split('?')[0].split('#')[0]);
  } catch (e) {
    return send(res, 400, 'Bad Request');
  }
  if (rel === '/') rel = '/index.html';

  const target = path.join(ROOT, rel);
  // 防目录穿越：解析后的路径必须仍在 public/ 之内
  if (target !== ROOT && !target.startsWith(ROOT + path.sep)) {
    return send(res, 403, 'Forbidden');
  }

  fs.stat(target, function (err, st) {
    if (err || !st.isFile()) {
      // 无扩展名的路径回退到同名 .html
      if (!path.extname(target)) {
        const alt = target + '.html';
        if (fs.existsSync(alt)) return stream(alt, res);
      }
      return send(res, 404, '404 Not Found');
    }
    stream(target, res);
  });
});

function stream(file, res) {
  const type = MIME[path.extname(file).toLowerCase()] || 'application/octet-stream';
  res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-cache' });
  fs.createReadStream(file).pipe(res);
}

server.listen(PORT, HOST, function () {
  console.log('SkillHub 复刻站已启动：http://localhost:' + PORT);
});
