/* ============================================================
   SkillHub 管理后台
   ------------------------------------------------------------
   数据全部走云数据库（PostgREST + RLS），没有任何本地假数据。
   门禁三态：未登录 → 已登录但不是管理员 → 管理员。
   模块：概览 / 技能管理 / 投稿审核 / 用户 / 操作日志
   ============================================================ */
(function () {
  'use strict';

  var C = window.SkillHubCloud;

  var CATS = [
    { id: 'efficiency', name: '效率工具' },
    { id: 'coding', name: '编程开发' },
    { id: 'design', name: '设计创作' },
    { id: 'data', name: '数据分析' },
    { id: 'writing', name: '内容写作' },
    { id: 'education', name: '学习教育' },
    { id: 'life', name: '生活助手' },
    { id: 'enterprise', name: '企业服务' },
  ];

  var STATUS = {
    pending: { label: '待审核', cls: 'adm-tag-warn' },
    approved: { label: '已通过', cls: 'adm-tag-ok' },
    rejected: { label: '已驳回', cls: 'adm-tag-danger' },
  };

  var state = {
    session: null,
    me: null, // admin_members 行
    view: 'overview',
    busy: false,
    pendingCount: 0,
  };

  var els = {
    gate: document.getElementById('adm-gate'),
    gateCard: document.getElementById('adm-gate-card'),
    app: document.getElementById('adm-app'),
    nav: document.getElementById('adm-nav'),
    view: document.getElementById('adm-view'),
    topUser: document.getElementById('adm-top-user'),
    toast: document.getElementById('adm-toast'),
  };

  /* ------------------------- 通用工具 ------------------------- */

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function catName(id) {
    var c = CATS.find(function (x) {
      return x.id === id;
    });
    return c ? c.name : id || '未分类';
  }

  function fmtNum(n) {
    if (n == null || isNaN(n)) return '—';
    return Number(n).toLocaleString('zh-CN');
  }

  /* 技能图标既可能是图片地址，也可能是 emoji。
     是地址就渲染成图片，否则当文本；两者都为空时回落到名称首字。 */
  function iconIsUrl(v) {
    return /^(https?:)?\/\//i.test(v) || /^\/(?!\/)/.test(v) || /^data:image\//i.test(v);
  }
  function initialOf(name) {
    var s = String(name == null ? '' : name).trim();
    if (!s) return '🧩';
    var c = s.charAt(0);
    return /[a-z]/.test(c) ? c.toUpperCase() : c;
  }
  function iconCell(icon, name) {
    var v = String(icon == null ? '' : icon).trim();
    var fb = esc(initialOf(name));
    if (iconIsUrl(v)) {
      return (
        '<span class="adm-icon adm-icon-pic">' +
        '<img src="' + esc(v) + '" alt="" loading="lazy" referrerpolicy="no-referrer"' +
        ' onerror="this.style.display=&#39;none&#39;;this.parentNode.classList.add(&#39;is-fb&#39;)">' +
        '<i class="adm-icon-fb">' + fb + '</i></span>'
      );
    }
    return '<span class="adm-icon">' + esc(v || initialOf(name)) + '</span>';
  }

  /* 弹窗表单里的图标实时预览 */
  function mountIconPreview(body) {
    var ic = body.querySelector('[name="icon"]');
    var nm = body.querySelector('[name="name"]');
    var host = body.querySelector('[data-icon-prev]');
    if (!ic || !host) return;
    var upd = function () {
      host.innerHTML = iconCell(ic.value, nm ? nm.value : '');
    };
    ic.addEventListener('input', upd);
    if (nm) nm.addEventListener('input', upd);
    upd();
  }

  function fmtSize(n) {
    if (!n) return '—';
    if (n < 1024) return n + ' B';
    if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
    return (n / 1024 / 1024).toFixed(2) + ' MB';
  }

  function fmtTime(v) {
    if (!v) return '—';
    var d = new Date(v);
    if (isNaN(d.getTime())) return String(v);
    var p = function (n) {
      return n < 10 ? '0' + n : '' + n;
    };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  }

  var toastTimer = null;
  function toast(text, kind) {
    if (!els.toast) return;
    els.toast.textContent = text;
    els.toast.style.background = kind === 'err' ? '#7A1A12' : kind === 'ok' ? '#0B5B33' : '#191919';
    els.toast.classList.add('is-on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      els.toast.classList.remove('is-on');
    }, 2600);
  }

  function errText(e) {
    return C.friendlyError(e);
  }

  /* ------------------------- 弹层 / 弹窗 ------------------------- */

  function openModal(opt) {
    var mask = document.createElement('div');
    mask.className = 'adm-mask';
    mask.innerHTML =
      '<div class="adm-modal" role="dialog" aria-modal="true">' +
      '<h3>' + esc(opt.title) + '</h3>' +
      (opt.desc ? '<p class="adm-sub">' + esc(opt.desc) + '</p>' : '') +
      '<div class="adm-modal-body" id="adm-modal-body"></div>' +
      '<div class="adm-modal-foot">' +
      '<button class="adm-btn" data-x="cancel" type="button">取消</button>' +
      '<button class="adm-btn adm-btn-primary" data-x="ok" type="button">' + esc(opt.okText || '保存') + '</button>' +
      '</div></div>';
    document.body.appendChild(mask);
    var body = mask.querySelector('#adm-modal-body');
    if (opt.bodyHtml) body.innerHTML = opt.bodyHtml;
    else if (opt.bodyNode) body.appendChild(opt.bodyNode);

    function close() {
      document.removeEventListener('keydown', onKey);
      mask.remove();
    }
    function onKey(e) {
      if (e.key === 'Escape') close();
    }
    document.addEventListener('keydown', onKey);
    mask.addEventListener('click', function (e) {
      if (e.target === mask) close();
    });
    mask.querySelector('[data-x="cancel"]').addEventListener('click', close);
    var okBtn = mask.querySelector('[data-x="ok"]');
    okBtn.addEventListener('click', async function () {
      if (state.busy) return;
      state.busy = true;
      okBtn.disabled = true;
      try {
        var keep = await opt.onOk(body, close);
        if (keep !== false) close();
      } catch (e) {
        toast(errText(e), 'err');
      } finally {
        state.busy = false;
        okBtn.disabled = false;
      }
    });
    return { close: close, body: body };
  }

  function confirmBox(title, desc, okText) {
    return new Promise(function (resolve) {
      var mask = document.createElement('div');
      mask.className = 'adm-mask';
      mask.innerHTML =
        '<div class="adm-modal" role="dialog" aria-modal="true">' +
        '<h3>' + esc(title) + '</h3>' +
        '<p class="adm-sub">' + esc(desc) + '</p>' +
        '<div class="adm-modal-foot">' +
        '<button class="adm-btn" data-x="no" type="button">取消</button>' +
        '<button class="adm-btn adm-btn-blue" data-x="yes" type="button">' + esc(okText || '确定') + '</button>' +
        '</div></div>';
      document.body.appendChild(mask);
      function done(v) {
        mask.remove();
        resolve(v);
      }
      mask.addEventListener('click', function (e) {
        if (e.target === mask) done(false);
      });
      mask.querySelector('[data-x="no"]').addEventListener('click', function () {
        done(false);
      });
      mask.querySelector('[data-x="yes"]').addEventListener('click', function () {
        done(true);
      });
    });
  }

  /* ------------------------- 云端访问 ------------------------- */

  async function cloud() {
    return C.getClient();
  }

  function rowsOf(res) {
    return (res && res.data) || [];
  }

  async function myMembership(userId) {
    var cl = await cloud();
    var res = await cl.database
      .from('admin_members')
      .select('id, user_id, display_name, role, created_at')
      .eq('user_id', userId)
      .limit(1);
    if (res.error) return null;
    return (res.data && res.data[0]) || null;
  }

  // 首次安装：第一个登录用户直接认领超级管理员（仅在尚无任何管理员时成功）。
  // 若已存在管理员，则退化为「申请待审」。
  async function becomeAdmin(session) {
    var cl = await cloud();
    var who = {
      user_id: session.user.id,
      display_name: session.user.name || session.user.phone || session.user.email || null,
    };
    var claim = await cl.database.from('admin_members').insert(
      Object.assign({ role: 'super_admin' }, who)
    );
    if (!claim.error) return 'super';
    // 认领失败（已有管理员）→ 退化申请，若已申请则忽略
    var req = await cl.database.from('admin_members').insert(
      Object.assign({ role: 'pending' }, who)
    );
    if (req.error) {
      // 若本人已是 pending，claim 的报错说明操作失败
      var m = await myMembership(session.user.id).catch(function () { return null; });
      if (m && m.role === 'pending') return 'pending';
      throw claim.error;
    }
    return 'pending';
  }

  async function audit(action, target, targetId, detail) {
    try {
      var cl = await cloud();
      var res = await cl.database.from('admin_audit_log').insert({
        actor_name: (state.me && state.me.display_name) || (state.session && state.session.user && state.session.user.name) || null,
        action: action,
        target: target || null,
        target_id: String(targetId == null ? '' : targetId),
        detail: detail || null,
      });
      // 表缺失或被 RLS 拒绝时，部分 SDK 只返回 error 而不抛异常 —— 必须显式识别，不能当成功
      if (res && res.error) throw res.error;
    } catch (e) {
      // 审计失败不阻断业务主流程，但必须可见。
      // 此前是静默吞掉，导致"表不存在时仍提示保存成功、实际零轨迹"完全无法察觉。
      console.error('[audit] 审计记录写入失败：action=' + action + ' target=' + target, e);
      try { toast('审计记录写入失败（内容已保存，但无操作轨迹）', 'err'); } catch (_) {}
    }
  }

  /* ------------------------- 导航 ------------------------- */

  // 分组式 IA：一级为业务域分组，二级为具体功能页
  var NAV_GROUPS = [
    {
      id: 'dash', label: '工作台', icon: 'grid',
      items: [{ id: 'overview', label: '概览', icon: 'grid' }],
    },
    {
      id: 'content', label: '内容运营', icon: 'file',
      items: [
        { id: 'content_global', label: '站点文案', icon: 'globe', group: 'global' },
        { id: 'content_sections', label: '首页区块', icon: 'layout', group: 'sections' },
        { id: 'content_pages', label: '页面文案', icon: 'pages', group: 'pages' },
      ],
    },
    {
      id: 'skills', label: '技能广场', icon: 'box',
      items: [
        { id: 'skills', label: '技能库', icon: 'box' },
        { id: 'submissions', label: '投稿审核', icon: 'inbox', badge: true },
      ],
    },
    {
      id: 'people', label: '用户与权限', icon: 'users',
      items: [
        { id: 'users', label: '用户列表', icon: 'users' },
        { id: 'team', label: '管理员团队', icon: 'shield' },
      ],
    },
    {
      id: 'system', label: '系统', icon: 'settings',
      items: [{ id: 'logs', label: '操作日志', icon: 'list' }],
    },
  ];

  // 扁平索引：路由、面包屑、默认展开用
  var NAV_INDEX = {};
  NAV_GROUPS.forEach(function (g) {
    g.items.forEach(function (it) { NAV_INDEX[it.id] = { item: it, group: g }; });
  });

  var ICONS = {
    grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>',
    file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>',
    globe: '<circle cx="12" cy="12" r="9"/><line x1="3" y1="12" x2="21" y2="12"/><path d="M12 3a15 15 0 0 1 0 18a15 15 0 0 1 0-18z"/>',
    layout: '<rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="9" x2="9" y2="21"/>',
    pages: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',
    box: '<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>',
    inbox: '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
    users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    list: '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>',
    check: '<polyline points="20 6 9 17 4 12"/>',
    info: '<circle cx="12" cy="12" r="9"/><line x1="12" y1="11" x2="12" y2="16"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
    zap: '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
    menu: '<line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>',
    rows: '<rect x="3" y="4" width="18" height="16" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="3" y1="15" x2="21" y2="15"/>',
    search: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
  };

  function icon(name) {
    return '<svg class="adm-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" ' +
      'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[name] || ICONS.file) + '</svg>';
  }

  // 分组折叠状态：undefined 视为展开；当前视图所在分组恒展开
  var navOpen = {};

  function renderNav() {
    var cur = NAV_INDEX[state.view] || NAV_INDEX.overview;
    if (cur) navOpen[cur.group.id] = true;

    els.nav.innerHTML = NAV_GROUPS.map(function (g) {
      var open = navOpen[g.id] !== false;
      var subs = g.items.map(function (it) {
        var badge = it.badge && state.pendingCount ? '<span class="adm-nav-dot">' + state.pendingCount + '</span>' : '';
        return (
          '<button class="adm-nav-item is-sub" data-view="' + it.id + '" type="button" aria-current="' +
          (state.view === it.id ? 'true' : 'false') + '">' + icon(it.icon) +
          '<span>' + esc(it.label) + '</span>' + badge + '</button>'
        );
      }).join('');
      return (
        '<div class="adm-nav-group-wrap">' +
        '<button class="adm-nav-group" data-group="' + g.id + '" type="button" aria-expanded="' + (open ? 'true' : 'false') + '">' +
        icon(g.icon) + '<span>' + esc(g.label) + '</span>' +
        '<svg class="adm-nav-chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
        'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>' +
        '</button>' +
        '<div class="adm-nav-subs"' + (open ? '' : ' hidden') + '>' + subs + '</div>' +
        '</div>'
      );
    }).join('');

    els.nav.querySelectorAll('[data-group]').forEach(function (b) {
      b.addEventListener('click', function () {
        var gid = b.getAttribute('data-group');
        navOpen[gid] = !(navOpen[gid] !== false);
        renderNav();
      });
    });
    els.nav.querySelectorAll('[data-view]').forEach(function (b) {
      b.addEventListener('click', function () {
        go(b.getAttribute('data-view'));
      });
    });
  }

  function go(view) {
    state.view = view;
    location.hash = '#/' + view;
    renderNav();
    paint();
  }

  /* ------------------------- 顶栏用户区 ------------------------- */

  function renderTopUser() {
    var u = state.session.user || {};
    var name = u.name || '（未设置昵称）';
    els.topUser.innerHTML =
      '<div class="adm-chip">' +
      '<span class="adm-av">' + esc(String(name).charAt(0).toUpperCase()) + '</span>' +
      '<span>' + esc(name) + '</span>' +
      '<span class="adm-tag ' + (state.me && state.me.role === 'super_admin' ? 'adm-tag-blue' : 'adm-tag-ok') + '">' +
      esc(state.me && state.me.role === 'super_admin' ? '超级管理员' : '管理员') + '</span>' +
      '<a href="/index.html" class="adm-link">返回前台</a>' +
      '<button class="adm-link" id="adm-out" type="button">退出</button>' +
      '</div>';
    document.getElementById('adm-out').addEventListener('click', async function () {
      await C.signOut().catch(function () {});
      location.href = '/index.html';
    });
  }

  /* ------------------------- 门禁 ------------------------- */

  function showGate(kind) {
    els.app.style.display = 'none';
    els.gate.style.display = 'flex';
    if (kind === 'guest') {
      els.gateCard.innerHTML =
        '<h1>请先登录</h1>' +
        '<p class="adm-sub">管理后台只对已授权的管理员开放。</p>' +
        '<button class="adm-btn adm-btn-primary" id="g-login" type="button" style="margin-top:20px;justify-content:center;width:100%">前往登录</button>' +
        '<p class="adm-mini" style="margin-top:14px">登录成功后会自动返回本页。</p>';
      document.getElementById('g-login').addEventListener('click', function () {
        location.href = '/login.html?redirect=/admin.html';
      });
      return;
    }
    if (kind === 'pending') {
      els.gateCard.innerHTML =
        '<h1>管理员申请审核中</h1>' +
        '<p class="adm-sub">你的申请已提交，等待超级管理员审批。审批通过后本页会自动进入后台。</p>' +
        '<div class="adm-uid">用户 ID：' + esc(state.session.user.id) + '</div>' +
        '<button class="adm-link" id="g-out" type="button" style="margin-top:18px">退出登录</button>';
      document.getElementById('g-out').addEventListener('click', async function () {
        await C.signOut().catch(function () {});
        location.reload();
      });
      scheduleStatusPoll();
      return;
    }
    // none：普通登录用户
    els.gateCard.innerHTML =
      '<h1>成为管理员</h1>' +
      '<p class="adm-sub">首次安装时，第一个登录账号可直接认领超级管理员；若已有管理员，则提交申请等待审批。</p>' +
      '<div class="adm-uid">用户 ID：' + esc(state.session.user.id) + '</div>' +
      '<button class="adm-btn adm-btn-primary" id="g-req" type="button" style="margin-top:20px;justify-content:center;width:100%">成为管理员</button>' +
      '<button class="adm-link" id="g-out" type="button" style="margin-top:14px">退出登录</button>';
    document.getElementById('g-req').addEventListener('click', async function () {
      var b = document.getElementById('g-req');
      b.disabled = true;
      b.textContent = '提交中…';
      try {
        var r = await becomeAdmin(state.session);
        if (r === 'super') {
          state.me = await myMembership(state.session.user.id);
          enterApp();
        } else {
          state.me = await myMembership(state.session.user.id);
          showGate('pending');
        }
      } catch (e) {
        b.disabled = false;
        b.textContent = '成为管理员';
        toast(errText(e), 'err');
      }
    });
    document.getElementById('g-out').addEventListener('click', async function () {
      await C.signOut().catch(function () {});
      location.reload();
    });
  }

  var pollTimer = null;
  function scheduleStatusPoll() {
    clearInterval(pollTimer);
    pollTimer = setInterval(async function () {
      try {
        var m = await myMembership(state.session.user.id);
        if (m && m.role !== 'pending') {
          clearInterval(pollTimer);
          state.me = m;
          enterApp();
        }
      } catch (e) {
        /* 静默 */
      }
    }, 4000);
  }

  /* ------------------------- 视图：概览 ------------------------- */

  async function viewOverview() {
    var cl = await cloud();
    var out = [];

    var head =
      '<div style="margin-bottom:20px"><h1 class="adm-h">概览</h1>' +
      '<p class="adm-sub">数据实时来自云端数据库，无任何本地缓存。</p></div>';

    try {
      var sTotal = await cl.database.from('skills').select('*', { count: 'exact', head: true });
      var subTotal = await cl.database.from('skill_submissions').select('*', { count: 'exact', head: true });
      var subPending = await cl.database
        .from('skill_submissions')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending');
      if (sTotal.error) throw sTotal.error;
      if (subTotal.error) throw subTotal.error;

      var pd = subPending.count || 0;
      state.pendingCount = pd;
      renderNav();

      var agg = await cl.database.from('skills').select('category, downloads, calls, author_type').limit(2000);
      var aggRows = rowsOf(agg);
      var dl = 0;
      var calls = 0;
      var byCat = {};
      aggRows.forEach(function (r) {
        dl += Number(r.downloads) || 0;
        calls += Number(r.calls) || 0;
        byCat[r.category || '未分类'] = (byCat[r.category || '未分类'] || 0) + 1;
      });

      out.push(
        '<div class="adm-grid">' +
        stat('技能目录总数', sTotal.count || 0, '云端 skills 表') +
        stat('累计下载量', fmtNum(dl), '全部技能 downloads 求和') +
        stat('累计调用量', fmtNum(calls), '全部技能 calls 求和') +
        stat('待审核投稿', pd, '状态为 pending', true) +
        '</div>'
      );

      var max = 0;
      Object.keys(byCat).forEach(function (k) {
        if (byCat[k] > max) max = byCat[k];
      });
      var bars = Object.keys(byCat)
        .sort(function (a, b) {
          return byCat[b] - byCat[a];
        })
        .map(function (k) {
          var pct = max ? Math.round((byCat[k] / max) * 100) : 0;
          return (
            '<div class="adm-bar-row"><span>' + esc(catName(k)) + '</span>' +
            '<span class="adm-bar-track"><span class="adm-bar-fill" style="width:' + pct + '%"></span></span>' +
            '<span style="text-align:right;color:rgba(0,0,0,.62)">' + byCat[k] + '</span></div>'
          );
        })
        .join('');

      out.push(
        '<div class="adm-panel" style="margin-bottom:20px"><div style="font-size:15px;font-weight:500;margin-bottom:14px">分类分布</div>' +
        '<div class="adm-bar-chart">' + (bars || '<div class="adm-mini">暂无数据</div>') + '</div></div>'
      );
    } catch (e) {
      out.push('<div class="adm-panel"><div class="adm-msg is-err">读取失败：' + esc(errText(e)) + '</div></div>');
    }

    // 最近操作日志
    try {
      var lg = await cl.database
        .from('admin_audit_log')
        .select('id, actor_name, action, target, target_id, created_at')
        .order('created_at', { ascending: false })
        .limit(8);
      var rows = rowsOf(lg);
      out.push(
        '<div class="adm-panel"><div style="display:flex;align-items:center;margin-bottom:12px">' +
        '<div style="font-size:15px;font-weight:500">最近操作</div>' +
        '<button class="adm-btn adm-btn-sm" id="ov-all" type="button" style="margin-left:auto">查看全部</button></div>' +
        tableHtml(
          ['时间', '操作人', '动作', '对象'],
          rows.length
            ? rows.map(function (r) {
                return (
                  '<tr><td class="adm-mini">' + esc(fmtTime(r.created_at)) + '</td>' +
                  '<td>' + esc(r.actor_name || '—') + '</td>' +
                  '<td class="t-main">' + esc(r.action) + '</td>' +
                  '<td>' + esc((r.target || '—') + (r.target_id ? ' #' + r.target_id : '')) + '</td></tr>'
                );
              }).join('')
            : emptyRow(4)
        ) + '</div>'
      );
    } catch (e) {
      /* 日志读不到不影响概览 */
    }

    els.view.innerHTML = head + out.join('');
    var ovAll = document.getElementById('ov-all');
    if (ovAll) ovAll.addEventListener('click', function () { go('logs'); });
  }

  function stat(label, value, foot, highlight) {
    return (
      '<div class="adm-stat"><div class="adm-stat-label">' + esc(label) + '</div>' +
      '<div class="adm-stat-value"' + (highlight ? ' style="color:#B54708"' : '') + '>' + esc(value) + '</div>' +
      (foot ? '<div class="adm-stat-foot">' + esc(foot) + '</div>' : '') + '</div>'
    );
  }

  function tableHtml(heads, bodyRows) {
    return (
      '<div class="adm-table-wrap"><table class="adm-table"><thead><tr>' +
      heads.map(function (h) {
        return '<th>' + esc(h) + '</th>';
      }).join('') +
      '</tr></thead><tbody>' + bodyRows + '</tbody></table></div>'
    );
  }

  function emptyRow(colspan, text) {
    return '<tr><td colspan="' + colspan + '"><div class="adm-empty">' + esc(text || '暂无数据') + '</div></td></tr>';
  }

  /* ------------------------- 视图：技能管理 ------------------------- */

  var skillsQ = { q: '', category: '', page: 1, size: 10 };

  function skillsFormHtml(s) {
    s = s || {};
    var tags = Array.isArray(s.tags) ? s.tags.join('、') : '';
    return (
      '<div class="adm-row2">' +
      '<div class="adm-field"><label>名称</label><input class="adm-input" name="name" value="' + esc(s.name) + '" placeholder="例如：会议纪要助手"></div>' +
      '<div class="adm-field"><label>图标</label><div class="adm-icon-row">' +
      '<input class="adm-input" name="icon" value="' + esc(s.icon || '') + '" placeholder="图片地址（https://…）或 emoji">' +
      '<span class="adm-icon-prev" data-icon-prev></span>' +
      '</div><div class="adm-help">支持图片直链或 emoji；留空 / 加载失败时自动用名称首字兜底。</div></div>' +
      '</div>' +
      '<div class="adm-row2">' +
      '<div class="adm-field"><label>分类</label><select class="adm-select" name="category">' +
      CATS.map(function (c) {
        return '<option value="' + c.id + '"' + (s.category === c.id ? ' selected' : '') + '>' + c.name + '</option>';
      }).join('') + '</select></div>' +
      '<div class="adm-field"><label>作者</label><input class="adm-input" name="author" value="' + esc(s.author || '') + '"></div>' +
      '</div>' +
      '<div class="adm-row2">' +
      '<div class="adm-field"><label>作者类型</label><select class="adm-select" name="author_type">' +
      ['个人', '企业'].map(function (t) {
        return '<option value="' + t + '"' + (s.author_type === t ? ' selected' : '') + '>' + t + '</option>';
      }).join('') + '</select></div>' +
      '<div class="adm-field"><label>评分（0-5）</label><input class="adm-input" name="rating" value="' + esc(s.rating == null ? '5.0' : s.rating) + '"></div>' +
      '</div>' +
      '<div class="adm-row2">' +
      '<div class="adm-field"><label>下载量</label><input class="adm-input" name="downloads" value="' + esc(s.downloads == null ? 0 : s.downloads) + '"></div>' +
      '<div class="adm-field"><label>调用量</label><input class="adm-input" name="calls" value="' + esc(s.calls == null ? 0 : s.calls) + '"></div>' +
      '</div>' +
      '<div class="adm-row2">' +
      '<div class="adm-field"><label>评价数</label><input class="adm-input" name="reviews" value="' + esc(s.reviews == null ? 0 : s.reviews) + '"></div>' +
      '<div class="adm-field"><label>标签（顿号 / 逗号分隔）</label><input class="adm-input" name="tags" value="' + esc(tags) + '" placeholder="会议、纪要、效率"></div>' +
      '</div>' +
      '<div class="adm-row2">' +
      '<div class="adm-field"><label>首页「近期飙升」排名</label><input class="adm-input" type="number" min="0" max="99" name="home_rank_trending" value="' + esc(s.home_rank_trending == null ? 0 : s.home_rank_trending) + '">' +
      '<div class="adm-help">填 1-99 按此顺序出现在首页飙升榜，填 0 表示不出现在该榜。</div></div>' +
      '<div class="adm-field"><label>首页「下载热榜」排名</label><input class="adm-input" type="number" min="0" max="99" name="home_rank_hot" value="' + esc(s.home_rank_hot == null ? 0 : s.home_rank_hot) + '">' +
      '<div class="adm-help">填 1-99 按此顺序出现在首页下载热榜，填 0 表示不出现在该榜。</div></div>' +
      '</div>' +
      '<div class="adm-field"><label>一句话描述</label><textarea class="adm-textarea" name="description" placeholder="这个 Skill 能做什么？">' + esc(s.description || '') + '</textarea></div>'
    );
  }

  function readSkillsForm(body) {
    var g = function (n) {
      var el = body.querySelector('[name="' + n + '"]');
      return el ? String(el.value).trim() : '';
    };
    var tagsRaw = g('tags');
    var tags = tagsRaw ? tagsRaw.split(/[,，、\s]+/).filter(Boolean).slice(0, 8) : [];
    var rating = parseFloat(g('rating'));
    var num = function (v) {
      var n = parseInt(v, 10);
      return isNaN(n) ? 0 : n;
    };
    var data = {
      name: g('name'),
      icon: g('icon') || null,
      category: g('category'),
      author: g('author') || null,
      author_type: g('author_type') || '个人',
      downloads: num(g('downloads')),
      calls: num(g('calls')),
      reviews: num(g('reviews')),
      rating: isNaN(rating) ? 0 : rating,
      tags: tags,
      description: g('description') || null,
      home_rank_trending: num(g('home_rank_trending')),
      home_rank_hot: num(g('home_rank_hot')),
    };
    return { data: data, name: data.name };
  }

  async function viewSkills() {
    var cl = await cloud();
    var from = (skillsQ.page - 1) * skillsQ.size;
    try {
      var query = cl.database.from('skills').select(
        'id, slug, name, category, description, icon, author, author_type, downloads, calls, rating, reviews, trending, featured, tags, created_at, home_rank_trending, home_rank_hot',
        { count: 'exact' }
      );
      if (skillsQ.category) query = query.eq('category', skillsQ.category);
      if (skillsQ.q) query = query.or('name.ilike.%' + skillsQ.q + '%,author.ilike.%' + skillsQ.q + '%,description.ilike.%' + skillsQ.q + '%');
      var res = await query.order('downloads', { ascending: false }).range(from, from + skillsQ.size - 1);
      if (res.error) throw res.error;
      var rows = rowsOf(res);
      var total = res.count || 0;
      var pages = Math.max(1, Math.ceil(total / skillsQ.size));

      var rankCell = function (v) {
        var n = Number(v) || 0;
        if (!n) return '<span class="adm-mini">—</span>';
        return '<span class="adm-tag adm-tag-ok">' + n + '</span>';
      };

      var body = rows.map(function (r) {
        return (
          '<tr>' +
          '<td class="adm-td-name"><div class="adm-cell">' + iconCell(r.icon, r.name) +
          '<div style="min-width:0"><div class="t-main">' + esc(r.name) + '</div>' +
          '<div class="adm-mini">' + esc(r.slug || ('#' + r.id)) + '</div></div></div></td>' +
          '<td>' + esc(catName(r.category)) + '</td>' +
          '<td>' + esc(r.author || '—') + ' <span class="adm-mini">' + esc(r.author_type || '') + '</span></td>' +
          '<td>' + fmtNum(r.downloads) + '</td>' +
          '<td>' + esc(r.rating == null ? '—' : Number(r.rating).toFixed(1)) + '</td>' +
          '<td>' + switchHtml('trending', r.id, !!r.trending, '飙升') + '</td>' +
          '<td>' + switchHtml('featured', r.id, !!r.featured, '精选') + '</td>' +
          '<td>' + rankCell(r.home_rank_trending) + '</td>' +
          '<td>' + rankCell(r.home_rank_hot) + '</td>' +
          '<td style="white-space:nowrap">' +
          '<button class="adm-btn adm-btn-sm" data-edit="' + r.id + '" type="button">编辑</button> ' +
          '<button class="adm-btn adm-btn-sm adm-btn-danger" data-del="' + r.id + '" type="button">删除</button>' +
          '</td></tr>'
        );
      }).join('');

      els.view.innerHTML =
        '<div style="display:flex;align-items:flex-end;margin-bottom:18px;gap:12px;flex-wrap:wrap">' +
        '<div><h1 class="adm-h">技能管理</h1><p class="adm-sub">共 ' + total + ' 条，直接写云端 skills 表。最后两列控制技能是否出现在首页排行榜及顺序。</p></div>' +
        '<button class="adm-btn adm-btn-blue" id="sk-new" type="button" style="margin-left:auto">+ 新建技能</button></div>' +
        '<div class="adm-bar">' +
        '<input class="adm-input" id="sk-q" placeholder="搜索名称 / 作者 / 描述" value="' + esc(skillsQ.q) + '">' +
        '<select class="adm-select" id="sk-cat"><option value="">全部分类</option>' +
        CATS.map(function (c) {
          return '<option value="' + c.id + '"' + (skillsQ.category === c.id ? ' selected' : '') + '>' + c.name + '</option>';
        }).join('') + '</select>' +
        '<button class="adm-btn" id="sk-reset" type="button">重置</button>' +
        '</div>' +
        tableHtml(['技能', '分类', '作者', '下载量', '评分', '飙升', '精选', '首页飙升榜', '首页下载榜', '操作'], body || emptyRow(10)) +
        pagerHtml(total, pages);

      bindSkillsEvents();
    } catch (e) {
      els.view.innerHTML = '<div class="adm-panel"><div class="adm-msg is-err">读取失败：' + esc(errText(e)) + '</div></div>';
    }
  }

  function switchHtml(field, id, on, label) {
    return (
      '<button class="adm-switch" type="button" aria-pressed="' + (on ? 'true' : 'false') + '" data-sw="' + field + '" data-id="' + id + '">' +
      '<span class="adm-switch-box"></span><span>' + esc(label) + '</span></button>'
    );
  }

  function pagerHtml(total, pages) {
    return (
      '<div class="adm-pager">共 ' + total + ' 条 / ' + pages + ' 页' +
      '<button class="adm-btn adm-btn-sm" data-page="prev" type="button"' + (state.view === 'skills' && skillsQ.page <= 1 ? ' disabled' : '') + '>上一页</button>' +
      '<span>第 ' + ((state.view === 'skills' ? skillsQ.page : 0) || 1) + ' 页</span>' +
      '<button class="adm-btn adm-btn-sm" data-page="next" type="button"' + (state.view === 'skills' && skillsQ.page >= pages ? ' disabled' : '') + '>下一页</button></div>'
    );
  }

  function bindSkillsEvents() {
    var $ = function (s) {
      return els.view.querySelector(s);
    };
    var q = $('#sk-q');
    var cat = $('#sk-cat');
    var timer = null;
    if (q)
      q.addEventListener('input', function () {
        clearTimeout(timer);
        timer = setTimeout(function () {
          skillsQ.q = q.value.trim();
          skillsQ.page = 1;
          viewSkills();
          setTimeout(function () {
            var el = document.getElementById('sk-q');
            if (el) {
              el.focus();
              el.setSelectionRange(el.value.length, el.value.length);
            }
          }, 0);
        }, 350);
      });
    if (cat)
      cat.addEventListener('change', function () {
        skillsQ.category = cat.value;
        skillsQ.page = 1;
        viewSkills();
      });
    var reset = $('#sk-reset');
    if (reset)
      reset.addEventListener('click', function () {
        skillsQ = { q: '', category: '', page: 1, size: 10 };
        viewSkills();
      });

    var pn = $('#sk-new');
    if (pn)
      pn.addEventListener('click', function () {
        var m = openModal({
          title: '新建技能',
          okText: '创建',
          bodyHtml: skillsFormHtml({}),
          onOk: async function (body) {
            var f = readSkillsForm(body);
            if (!f.name) throw new Error('请填写技能名称。');
            var cl = await cloud();
            var slug = f.name.replace(/[^\w一-龥]/g, '') + '-' + Date.now().toString(36);
            var res = await cl.database.from('skills').insert(Object.assign({ slug: slug }, f.data)).select();
            if (res.error) throw res.error;
            if (!rowsOf(res).length) throw new Error('创建失败：当前账号没有写入权限。');
            await audit('新建技能', 'skills', rowsOf(res)[0].id, f.name);
            toast('已创建「' + f.name + '」', 'ok');
            viewSkills();
          },
        });
        mountIconPreview(m.body);
      });

    els.view.querySelectorAll('[data-page]').forEach(function (b) {
      b.addEventListener('click', function () {
        var p = b.getAttribute('data-page');
        if (p === 'prev') skillsQ.page = Math.max(1, skillsQ.page - 1);
        else skillsQ.page += 1;
        viewSkills();
      });
    });

    els.view.querySelectorAll('[data-sw]').forEach(function (b) {
      b.addEventListener('click', async function () {
        if (state.busy) return;
        var id = parseInt(b.getAttribute('data-id'), 10);
        var field = b.getAttribute('data-sw');
        var next = b.getAttribute('aria-pressed') !== 'true';
        state.busy = true;
        try {
          var patch = {};
          patch[field] = next;
          var cl = await cloud();
          var res = await cl.database.from('skills').update(patch).eq('id', id).select('id');
          if (res.error) throw res.error;
          if (!rowsOf(res).length) throw new Error('保存失败：没有该记录的写入权限。');
          await audit('切换' + (field === 'trending' ? '飙升' : '精选'), 'skills', id, String(next));
          b.setAttribute('aria-pressed', String(next));
          toast('已更新', 'ok');
        } catch (e) {
          toast(errText(e), 'err');
        } finally {
          state.busy = false;
        }
      });
    });

    els.view.querySelectorAll('[data-edit]').forEach(function (b) {
      b.addEventListener('click', async function () {
        var id = parseInt(b.getAttribute('data-edit'), 10);
        var cl = await cloud();
        var res = await cl.database.from('skills').select('*').eq('id', id).single();
        if (res.error) return toast(errText(res.error), 'err');
        var m = openModal({
          title: '编辑技能',
          okText: '保存',
          bodyHtml: skillsFormHtml(res.data),
          onOk: async function (body) {
            var f = readSkillsForm(body);
            if (!f.name) throw new Error('请填写技能名称。');
            var c2 = await cloud();
            var up = await c2.database.from('skills').update(f.data).eq('id', id).select('id');
            if (up.error) throw up.error;
            if (!rowsOf(up).length) throw new Error('保存失败：没有该记录的写入权限。');
            await audit('编辑技能', 'skills', id, f.name);
            toast('已保存', 'ok');
            viewSkills();
          },
        });
        mountIconPreview(m.body);
      });
    });

    els.view.querySelectorAll('[data-del]').forEach(function (b) {
      b.addEventListener('click', async function () {
        var id = parseInt(b.getAttribute('data-del'), 10);
        var cl = await cloud();
        var res = await cl.database.from('skills').select('name').eq('id', id).single();
        var nm = (res.data && res.data.name) || ('#' + id);
        var ok = await confirmBox('删除技能', '将永久删除「' + nm + '」，此操作不可恢复。', '确认删除');
        if (!ok) return;
        try {
          var del = await cl.database.from('skills').delete().eq('id', id).select('id');
          if (del.error) throw del.error;
          if (!rowsOf(del).length) throw new Error('删除失败：没有该记录的删除权限。');
          await audit('删除技能', 'skills', id, nm);
          toast('已删除', 'ok');
          viewSkills();
        } catch (e) {
          toast(errText(e), 'err');
        }
      });
    });
  }

  /* ------------------------- 视图：投稿审核 ------------------------- */

  var subQ = { status: 'pending', page: 1, size: 10 };

  async function viewSubmissions() {
    var cl = await cloud();
    var from = (subQ.page - 1) * subQ.size;
    try {
      var query = cl.database
        .from('skill_submissions')
        .select('id, owner_id, owner_name, title, summary, category, file_name, file_path, file_size, status, created_at', { count: 'exact' });
      if (subQ.status) query = query.eq('status', subQ.status);
      var res = await query.order('created_at', { ascending: false }).range(from, from + subQ.size - 1);
      if (res.error) throw res.error;
      var rows = rowsOf(res);
      var total = res.count || 0;
      var pages = Math.max(1, Math.ceil(total / subQ.size));

      var body = rows.map(function (r) {
        var st = STATUS[r.status] || { label: r.status, cls: '' };
        return (
          '<tr>' +
          '<td><div style="min-width:0"><div class="t-main">' + esc(r.title) + '</div>' +
          '<div class="adm-mini">' + esc(r.summary || '（无简介）') + '</div></div></td>' +
          '<td>' + esc(r.owner_name || '—') + '<div class="adm-mini">' + esc(String(r.owner_id || '').slice(0, 10)) + '…</div></td>' +
          '<td>' + esc(catName(r.category)) + '</td>' +
          '<td class="adm-mini">' + esc(r.file_name || '无附件') + '<br>' + esc(fmtSize(r.file_size)) + '</td>' +
          '<td><span class="adm-tag ' + st.cls + '">' + esc(st.label) + '</span></td>' +
          '<td class="adm-mini">' + esc(fmtTime(r.created_at)) + '</td>' +
          '<td style="white-space:nowrap">' +
          (r.status === 'pending'
            ? '<button class="adm-btn adm-btn-sm adm-btn-blue" data-ap="' + r.id + '" type="button">通过</button> ' +
              '<button class="adm-btn adm-btn-sm" data-rj="' + r.id + '" type="button">驳回</button> '
            : '<button class="adm-btn adm-btn-sm" data-bk="' + r.id + '" type="button">退回待审</button> ') +
          '<button class="adm-btn adm-btn-sm" data-pb="' + r.id + '" type="button">上架到技能库</button> ' +
          '<button class="adm-btn adm-btn-sm adm-btn-danger" data-dl="' + r.id + '" type="button">删除</button>' +
          '</td></tr>'
        );
      }).join('');

      els.view.innerHTML =
        '<div style="display:flex;align-items:flex-end;margin-bottom:18px;gap:12px;flex-wrap:wrap">' +
        '<div><h1 class="adm-h">投稿审核</h1><p class="adm-sub">所有人提交的 Skill 包，管理员可见并处置。</p></div></div>' +
        '<div class="adm-bar">' +
        ['pending|待审核', 'approved|已通过', 'rejected|已驳回', '|全部'].map(function (o) {
          var p = o.split('|');
          return '<button class="adm-btn' + (subQ.status === p[0] ? ' adm-btn-primary' : '') + '" data-st="' + p[0] + '" type="button">' + p[1] + '</button>';
        }).join(' ') +
        '</div>' +
        tableHtml(['投稿', '投稿人', '分类', '附件', '状态', '提交时间', '操作'], body || emptyRow(7)) +
        '<div class="adm-pager">共 ' + total + ' 条 / ' + pages + ' 页' +
        '<button class="adm-btn adm-btn-sm" data-sp="prev" type="button"' + (subQ.page <= 1 ? ' disabled' : '') + '>上一页</button>' +
        '<span>第 ' + subQ.page + ' 页</span>' +
        '<button class="adm-btn adm-btn-sm" data-sp="next" type="button"' + (subQ.page >= pages ? ' disabled' : '') + '>下一页</button></div>';

      bindSubEvents();
    } catch (e) {
      els.view.innerHTML = '<div class="adm-panel"><div class="adm-msg is-err">读取失败：' + esc(errText(e)) + '</div></div>';
    }
  }

  function bindSubEvents() {
    els.view.querySelectorAll('[data-st]').forEach(function (b) {
      b.addEventListener('click', function () {
        subQ.status = b.getAttribute('data-st');
        subQ.page = 1;
        viewSubmissions();
      });
    });
    els.view.querySelectorAll('[data-sp]').forEach(function (b) {
      b.addEventListener('click', function () {
        subQ.page = b.getAttribute('data-sp') === 'prev' ? Math.max(1, subQ.page - 1) : subQ.page + 1;
        viewSubmissions();
      });
    });

    var setStatus = async function (id, status, label) {
      state.busy = true;
      try {
        var cl = await cloud();
        var res = await cl.database.from('skill_submissions').update({ status: status }).eq('id', id).select('id, title');
        if (res.error) throw res.error;
        if (!rowsOf(res).length) throw new Error('更新失败：没有该记录的写入权限。');
        await audit('投稿' + label, 'skill_submissions', id, (rowsOf(res)[0].title || ''));
        refreshPending();
        toast('已' + label, 'ok');
        viewSubmissions();
      } catch (e) {
        toast(errText(e), 'err');
      } finally {
        state.busy = false;
      }
    };

    ['ap|approved|通过', 'rj|rejected|驳回', 'bk|pending|退回待审'].forEach(function (m) {
      var p = m.split('|');
      els.view.querySelectorAll('[data-' + p[0] + ']').forEach(function (b) {
        b.addEventListener('click', function () {
          setStatus(parseInt(b.getAttribute('data-' + p[0]), 10), p[1], p[2]);
        });
      });
    });

    els.view.querySelectorAll('[data-pb]').forEach(function (b) {
      b.addEventListener('click', async function () {
        var id = parseInt(b.getAttribute('data-pb'), 10);
        var cl = await cloud();
        var res = await cl.database.from('skill_submissions').select('*').eq('id', id).single();
        if (res.error || !res.data) return toast('读取投稿失败', 'err');
        var r = res.data;
        openModal({
          title: '上架到技能库',
          desc: '把这条投稿写入公共技能目录 skills，前台即可看到。',
          okText: '确认上架',
          bodyHtml:
            '<div class="adm-row2">' +
            '<div class="adm-field"><label>名称</label><input class="adm-input" name="name" value="' + esc(r.title) + '"></div>' +
            '<div class="adm-field"><label>图标</label><input class="adm-input" name="icon" value="🧩"></div>' +
            '</div>' +
            '<div class="adm-row2">' +
            '<div class="adm-field"><label>分类</label><select class="adm-select" name="category">' +
            CATS.map(function (c) {
              return '<option value="' + c.id + '"' + (r.category === c.id ? ' selected' : '') + '>' + c.name + '</option>';
            }).join('') + '</select></div>' +
            '<div class="adm-field"><label>作者</label><input class="adm-input" name="author" value="' + esc(r.owner_name || '') + '"></div>' +
            '</div>' +
            '<div class="adm-field"><label>一句话描述</label><textarea class="adm-textarea" name="description">' + esc(r.summary || '') + '</textarea></div>',
          onOk: async function (body) {
            var g = function (n) {
              var el = body.querySelector('[name="' + n + '"]');
              return el ? String(el.value).trim() : '';
            };
            if (!g('name')) throw new Error('请填写名称。');
            var c2 = await cloud();
            var ins = await c2.database
              .from('skills')
              .insert({
                slug: g('name').replace(/[^\w一-龥]/g, '') + '-' + Date.now().toString(36),
                name: g('name'),
                icon: g('icon') || '🧩',
                category: g('category'),
                author: g('author') || null,
                author_type: '个人',
                description: g('description') || null,
                downloads: 0,
                calls: 0,
                reviews: 0,
                rating: 5.0,
                trending: false,
                featured: false,
                tags: [],
              })
              .select('id');
            if (ins.error) throw ins.error;
            if (!rowsOf(ins).length) throw new Error('上架失败：当前账号没有写入 skills 的权限。');
            await c2.database.from('skill_submissions').update({ status: 'approved' }).eq('id', id);
            await audit('投稿上架', 'skills', rowsOf(ins)[0].id, g('name'));
            toast('已上架到技能库', 'ok');
            refreshPending();
            viewSubmissions();
          },
        });
      });
    });

    els.view.querySelectorAll('[data-dl]').forEach(function (b) {
      b.addEventListener('click', async function () {
        var id = parseInt(b.getAttribute('data-dl'), 10);
        var cl = await cloud();
        var res = await cl.database.from('skill_submissions').select('title').eq('id', id).single();
        var nm = (res.data && res.data.title) || ('#' + id);
        var ok = await confirmBox('删除投稿', '将永久删除投稿「' + nm + '」，此操作不可恢复。', '确认删除');
        if (!ok) return;
        try {
          var del = await cl.database.from('skill_submissions').delete().eq('id', id).select('id');
          if (del.error) throw del.error;
          if (!rowsOf(del).length) throw new Error('删除失败：没有该记录的删除权限。');
          await audit('删除投稿', 'skill_submissions', id, nm);
          refreshPending();
          toast('已删除', 'ok');
          viewSubmissions();
        } catch (e) {
          toast(errText(e), 'err');
        }
      });
    });
  }

  async function refreshPending() {
    try {
      var cl = await cloud();
      var res = await cl.database
        .from('skill_submissions')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending');
      state.pendingCount = res.count || 0;
      renderNav();
    } catch (e) {
      /* 静默 */
    }
  }

  /* ------------------------- 视图：团队（管理员名单） ------------------------- */

  async function viewTeam() {
    var cl = await cloud();
    try {
      var res = await cl.database
        .from('admin_members')
        .select('id, user_id, display_name, role, created_at')
        .order('created_at', { ascending: true });
      if (res.error) throw res.error;
      var rows = rowsOf(res);
      var body = rows.map(function (r) {
        var isMe = state.session && state.session.user.id === r.user_id;
        var roleTag = r.role === 'super_admin' ? 'adm-tag-blue' : r.role === 'admin' ? 'adm-tag-ok' : 'adm-tag-warn';
        var label = r.role === 'super_admin' ? '超级管理员' : r.role === 'admin' ? '管理员' : '待审批';
        var actions = '';
        if (r.role === 'pending') {
          actions +=
            '<button class="adm-btn adm-btn-sm adm-btn-blue" data-apm="' + esc(r.user_id) + '" type="button">通过</button> ' +
            '<button class="adm-btn adm-btn-sm adm-btn-danger" data-rm="' + esc(r.user_id) + '" type="button">拒绝</button>';
        } else if (!isMe) {
          actions += '<button class="adm-btn adm-btn-sm adm-btn-danger" data-rm="' + esc(r.user_id) + '" type="button">移除</button>';
        } else {
          actions += '<span class="adm-mini">本人</span>';
        }
        return (
          '<tr>' +
          '<td><div class="adm-cell"><span class="adm-icon">' + esc(String(r.display_name || '?').charAt(0).toUpperCase()) + '</span>' +
          '<div style="min-width:0"><div class="t-main">' + esc(r.display_name || '—') + '</div>' +
          '<div class="adm-mini">' + esc(r.user_id) + '</div></div></div></td>' +
          '<td><span class="adm-tag ' + roleTag + '">' + label + '</span></td>' +
          '<td class="adm-mini">' + esc(fmtTime(r.created_at)) + '</td>' +
          '<td style="white-space:nowrap">' + actions + '</td>' +
          '</tr>'
        );
      }).join('');

      els.view.innerHTML =
        '<div style="margin-bottom:18px"><h1 class="adm-h">团队</h1>' +
        '<p class="adm-sub">管理员名单与权限。待审批成员「通过」后即刻获得后台访问权。</p></div>' +
        tableHtml(['成员', '角色', '加入时间', '操作'], body || emptyRow(4, '还没有任何成员，去前台登录后将自动获得认领入口。'));
      bindTeamEvents();
    } catch (e) {
      els.view.innerHTML = '<div class="adm-panel"><div class="adm-msg is-err">读取失败：' + esc(errText(e)) + '</div></div>';
    }
  }

  function bindTeamEvents() {
    els.view.querySelectorAll('[data-apm]').forEach(function (b) {
      b.addEventListener('click', async function () {
        var uid = b.getAttribute('data-apm');
        try {
          var cl = await cloud();
          var res = await cl.database.from('admin_members').update({ role: 'admin' }).eq('user_id', uid).select('user_id');
          if (res.error) throw res.error;
          if (!rowsOf(res).length) throw new Error('操作失败：当前账号没有权限。');
          await audit('批准管理员', 'admin_members', uid, '');
          toast('已通过', 'ok');
          viewTeam();
        } catch (e) {
          toast(errText(e), 'err');
        }
      });
    });
    els.view.querySelectorAll('[data-rm]').forEach(function (b) {
      b.addEventListener('click', async function () {
        var uid = b.getAttribute('data-rm');
        if (uid === (state.session && state.session.user.id)) return;
        var ok = await confirmBox('移除成员', '将把该成员移出管理团队。', '确认移除');
        if (!ok) return;
        try {
          var cl = await cloud();
          var res = await cl.database.from('admin_members').delete().eq('user_id', uid).select('user_id');
          if (res.error) throw res.error;
          if (!rowsOf(res).length) throw new Error('操作失败：当前账号没有权限。');
          await audit('移除管理员', 'admin_members', uid, '');
          toast('已移除', 'ok');
          viewTeam();
        } catch (e) {
          toast(errText(e), 'err');
        }
      });
    });
  }

  /* ------------------------- 视图：用户 ------------------------- */

  async function viewUsers() {
    var cl = await cloud();
    try {
      var res = await cl.database
        .from('skill_submissions')
        .select('owner_id, owner_name, file_size, created_at, status')
        .order('created_at', { ascending: false })
        .limit(1000);
      if (res.error) throw res.error;
      var rows = rowsOf(res);
      var map = {};
      rows.forEach(function (r) {
        var k = r.owner_id || '未知';
        if (!map[k]) map[k] = { id: k, name: r.owner_name || '—', count: 0, size: 0, last: r.created_at, pending: 0 };
        map[k].count += 1;
        map[k].size += Number(r.file_size) || 0;
        if (r.status === 'pending') map[k].pending += 1;
        if (!map[k].last || new Date(r.created_at) > new Date(map[k].last)) map[k].last = r.created_at;
      });
      var list = Object.keys(map).map(function (k) {
        return map[k];
      });

      var body = list.map(function (u) {
        var isMe = state.session && state.session.user && u.id === state.session.user.id;
        var isAdmin = false;
        return (
          '<tr>' +
          '<td><div class="adm-cell"><span class="adm-icon">' + esc(String(u.name).charAt(0)) + '</span>' +
          '<div style="min-width:0"><div class="t-main">' + esc(u.name) + (isMe ? ' <span class="adm-tag adm-tag-blue">我</span>' : '') + '</div>' +
          '<div class="adm-mini">' + esc(u.id) + '</div></div></div></td>' +
          '<td>' + u.count + '</td>' +
          '<td>' + (u.pending ? '<span class="adm-tag adm-tag-warn">' + u.pending + ' 待审</span>' : '0') + '</td>' +
          '<td class="adm-mini">' + esc(u.size ? fmtSize(u.size) : '—') + '</td>' +
          '<td class="adm-mini">' + esc(fmtTime(u.last)) + '</td>' +
          '<td>' + (isAdmin ? '<span class="adm-tag adm-tag-ok">管理员</span>' : '<span class="adm-mini">普通创作者</span>') + '</td>' +
          '</tr>'
        );
      }).join('');

      els.view.innerHTML =
        '<div style="margin-bottom:18px"><h1 class="adm-h">用户</h1>' +
        '<p class="adm-sub">按投稿聚合出来的创作者名单（管理团队成员的新增与晋升见「团队」页）。</p></div>' +
        tableHtml(['用户', '投稿数', '待审', '附件总量', '最近提交', '身份'], body || emptyRow(6, '还没有任何用户提交过内容。'));
    } catch (e) {
      els.view.innerHTML = '<div class="adm-panel"><div class="adm-msg is-err">读取失败：' + esc(errText(e)) + '</div></div>';
    }
  }

  /* ------------------------- 视图：操作日志 ------------------------- */

  var logQ = { page: 1, size: 15 };

  async function viewLogs() {
    var cl = await cloud();
    var from = (logQ.page - 1) * logQ.size;
    try {
      var res = await cl.database
        .from('admin_audit_log')
        .select('id, actor_id, actor_name, action, target, target_id, detail, created_at', { count: 'exact' })
        .order('created_at', { ascending: false })
        .range(from, from + logQ.size - 1);
      if (res.error) throw res.error;
      var rows = rowsOf(res);
      var total = res.count || 0;
      var pages = Math.max(1, Math.ceil(total / logQ.size));

      var body = rows.map(function (r) {
        var mine = state.session && r.actor_id === state.session.user.id;
        return (
          '<tr>' +
          '<td class="adm-mini">' + esc(fmtTime(r.created_at)) + '</td>' +
          '<td>' + esc(r.actor_name || '—') + (mine ? ' <span class="adm-tag adm-tag-blue">我</span>' : '') +
          '<div class="adm-mini">' + esc(String(r.actor_id || '').slice(0, 10)) + '…</div></td>' +
          '<td class="t-main">' + esc(r.action) + '</td>' +
          '<td class="adm-mini">' + esc((r.target || '—') + (r.target_id ? ' #' + r.target_id : '')) + '</td>' +
          '<td class="adm-mini">' + esc(r.detail || '') + '</td>' +
          '</tr>'
        );
      }).join('');

      els.view.innerHTML =
        '<div style="margin-bottom:18px"><h1 class="adm-h">操作日志</h1>' +
        '<p class="adm-sub">后台所有写操作都会落到这里，共 ' + total + ' 条。</p></div>' +
        tableHtml(['时间', '操作人', '动作', '对象', '备注'], body || emptyRow(5, '还没有任何后台操作记录。')) +
        '<div class="adm-pager">共 ' + total + ' 条 / ' + pages + ' 页' +
        '<button class="adm-btn adm-btn-sm" data-lp="prev" type="button"' + (logQ.page <= 1 ? ' disabled' : '') + '>上一页</button>' +
        '<span>第 ' + logQ.page + ' 页</span>' +
        '<button class="adm-btn adm-btn-sm" data-lp="next" type="button"' + (logQ.page >= pages ? ' disabled' : '') + '>下一页</button></div>';

      els.view.querySelectorAll('[data-lp]').forEach(function (b) {
        b.addEventListener('click', function () {
          logQ.page = b.getAttribute('data-lp') === 'prev' ? Math.max(1, logQ.page - 1) : logQ.page + 1;
          viewLogs();
        });
      });
    } catch (e) {
      els.view.innerHTML = '<div class="adm-panel"><div class="adm-msg is-err">读取失败：' + esc(errText(e)) + '</div></div>';
    }
  }

  /* ------------------------- 视图：内容管理（CMS） ------------------------- */

  var CONTENT_GROUPS = {
    global: { label: '站点文案', desc: '品牌名、导航、页脚、英雄区等全站通用文案。保存后线上立即生效，无需重新部署。' },
    sections: { label: '首页区块', desc: '首页各内容区块的标题与说明文字。' },
    pages: { label: '页面文案', desc: '技能广场、企业专区、插件、MCP、SOUL 等子页面的标题与介绍。' },
  };

  // 各内容键的编辑器元信息：列表简介、面板描述、图标、字段帮助/必填、预览类型。
  // 属于编辑器 UI 元数据（不随前台内容下发），字段定义仍以库中 schema 为准。
  var CONTENT_META = {
    g_brand: {
      icon: 'globe', brief: '站点名称、Logo 与首页描述', preview: 'brand',
      desc: '设置网站的品牌名称、Logo 替代文本和首页链接描述，这些信息将显示在网站各处。',
      fields: {
        name: { required: true, label: '品牌名称', help: '显示在网站顶部的品牌名称，建议使用简短、易识别的名称。' },
        home_aria: { required: true, label: '首页链接描述', help: '用于说明首页链接的用途，将在导航或搜索结果中显示。' },
        logo_alt: { required: true, help: '当 Logo 无法正常显示时的替代文本，有助于提升网站的可访问性和 SEO 效果。' },
      },
    },
    g_hero: {
      icon: 'zap', brief: '首页顶部核心文案与描述', preview: 'hero',
      desc: '设置首页英雄区的主标题、副标题与按钮文案，这是访客打开网站看到的第一屏。',
      fields: {
        title: { required: true, help: '英雄区最醒目的大标题，建议一句话说清核心价值。' },
        subtitle: { help: '补充说明主标题，介绍平台定位与为用户带来的价值。' },
        cta1_text: { help: '主按钮上的文字，引导用户完成最主要的一步操作。' },
        cta1_href: { help: '主按钮跳转的链接地址，站内路径请以 / 开头。' },
        cta2_text: { help: '次按钮上的文字，提供次级选择。' },
        cta2_href: { help: '次按钮跳转的链接地址，站内路径请以 / 开头。' },
      },
    },
    g_nav: {
      icon: 'menu', brief: '顶部导航菜单的链接与文案', preview: 'nav',
      desc: '设置顶部导航的菜单项，可增删或调整每一项的文字与链接，保存后全站导航立即更新。',
      fields: {
        items: { help: '按顺序显示在页面顶部；点击「+ 添加一项」可新增菜单。' },
      },
    },
    g_footer: {
      icon: 'rows', brief: '网站底部的文案与链接', preview: 'footer',
      desc: '设置页脚的简介、链接分栏与版权声明，显示在全站每个页面的底部。',
      fields: {
        desc: { help: '一句话介绍平台，显示在页脚左侧。' },
        columns: { help: '页脚链接分栏；每栏含标题与若干链接，可增删。' },
        copyright: { help: '页脚最底部的版权声明文字。' },
      },
    },
    g_meta: {
      icon: 'search', brief: '网页标题、描述等 SEO 信息', preview: 'meta',
      desc: '设置浏览器标签标题与页面描述，会显示在搜索结果与分享卡片中。',
      fields: {
        title: { required: true, help: '浏览器标签页标题，也是搜索结果的主标题，建议 60 字以内。' },
        description: { help: '页面描述会显示在搜索结果摘要中，建议控制在 120 字以内。' },
      },
    },
  };
  var GROUP_META_DEFAULT = {
    sections: { icon: 'layout', brief: '区块标题与副标题', preview: 'section', desc: '设置该首页区块的标题与副标题文案。', fields: {} },
    pages: { icon: 'pages', brief: '页面标题与简介', preview: 'page', desc: '设置该页面的标题与简介文案。', fields: {} },
  };
  function contentMeta(row) {
    return CONTENT_META[row.key] || GROUP_META_DEFAULT[row.group_name] ||
      { icon: 'file', brief: '', preview: 'generic', desc: '', fields: {} };
  }

  // 内容工作台状态：当前分组、已加载行、选中键、是否有未保存修改
  var contentState = null;

  async function viewContent(groupName) {
    var cl = await cloud();
    var meta = CONTENT_GROUPS[groupName] || { label: '内容管理', desc: '' };
    try {
      var res = await cl.database
        .from('site_content')
        .select('key, group_name, title, schema, value, updated_at')
        .order('group_name')
        .order('key');
      if (res.error) throw res.error;
      var rows = rowsOf(res).filter(function (r) { return r.group_name === groupName; });
      contentState = { group: groupName, rows: rows, sel: rows.length ? rows[0].key : null, dirty: false };

      var out =
        '<div class="adm-cms-head"><div>' +
        '<h1 class="adm-h">' + esc(meta.label) +
        '<a class="adm-link adm-cms-plink" href="/index.html" target="_blank" rel="noopener">预览前台 ↗</a></h1>' +
        '<p class="adm-sub">' + esc(meta.desc) + '</p></div></div>';

      if (!rows.length) {
        out += '<div class="adm-panel"><div class="adm-empty">该分组暂无内容</div></div>';
        els.view.innerHTML = out;
        return;
      }
      out += '<div class="adm-cms">' +
        '<aside class="adm-cms-list" id="adm-cms-list"></aside>' +
        '<section class="adm-cms-editor adm-panel" id="adm-cms-editor"></section></div>';
      els.view.innerHTML = out;
      renderContentList();
      renderContentEditor();
    } catch (e) {
      els.view.innerHTML = '<div class="adm-panel"><div class="adm-msg is-err">读取失败：' + esc(errText(e)) + '</div></div>';
    }
  }

  function renderContentList() {
    var host = document.getElementById('adm-cms-list');
    if (!host || !contentState) return;
    host.innerHTML = contentState.rows.map(function (r) {
      var m = contentMeta(r);
      var act = r.key === contentState.sel;
      return (
        '<button class="adm-cms-item' + (act ? ' is-act' : '') + '" data-ckey-sel="' + esc(r.key) +
        '" type="button"' + (act ? ' aria-current="true"' : '') + '>' +
        '<span class="adm-cms-ico">' + icon(m.icon) + '</span>' +
        '<span class="adm-cms-item-tx"><span class="adm-cms-item-t">' + esc(r.title) + '</span>' +
        (m.brief ? '<span class="adm-cms-item-b">' + esc(m.brief) + '</span>' : '') +
        '</span></button>'
      );
    }).join('');
    host.querySelectorAll('[data-ckey-sel]').forEach(function (b) {
      b.addEventListener('click', function () {
        selectContent(b.getAttribute('data-ckey-sel'));
      });
    });
  }

  function selectedRow() {
    if (!contentState) return null;
    for (var i = 0; i < contentState.rows.length; i++) {
      if (contentState.rows[i].key === contentState.sel) return contentState.rows[i];
    }
    return null;
  }

  function selectContent(key) {
    if (!contentState || key === contentState.sel) return;
    if (contentState.dirty && !window.confirm('当前修改尚未保存，确定切换并放弃修改？')) return;
    contentState.sel = key;
    contentState.dirty = false;
    renderContentList();
    renderContentEditor();
  }

  function renderContentEditor() {
    var host = document.getElementById('adm-cms-editor');
    var row = selectedRow();
    if (!host || !row) return;
    var m = contentMeta(row);
    var schema = Array.isArray(row.schema) ? row.schema : [];

    host.innerHTML =
      '<div class="adm-cms-ed-head">' +
      '<div><h2 class="adm-cms-ed-t">' + esc(row.title) + '</h2>' +
      '<p class="adm-sub">' + esc(m.desc || ('编辑「' + row.title + '」的内容。')) + '</p></div>' +
      '<div class="adm-cms-ed-actions">' +
      '<span class="adm-saved" id="adm-cms-saved" hidden>' + icon('check') + '已保存</span>' +
      '<button class="adm-btn adm-btn-blue" id="adm-cms-save" type="button">保存修改</button>' +
      '</div></div>' +
      '<div class="adm-cms-fields" id="adm-cms-fields"></div>' +
      '<div class="adm-cms-preview"><h3 class="adm-cms-prev-t">展示预览</h3>' +
      '<p class="adm-mini">以下为基于当前设置的实际展示效果。</p>' +
      '<div class="adm-cms-prev-box" id="adm-cms-prev"></div></div>' +
      '<div class="adm-cms-note">' + icon('info') + '<span>保存后立即生效，无需重新部署。</span></div>';

    var fields = document.getElementById('adm-cms-fields');
    schema.forEach(function (def) {
      fields.appendChild(contentField(def, row.value ? row.value[def.name] : undefined, m.fields[def.name]));
    });

    // oninput 用属性赋值而非 addEventListener，避免重复渲染时监听器叠加；
    // 输入时同时做脏标记与实时预览刷新
    host.oninput = function () {
      onContentDirty();
      refreshContentPreview();
    };
    document.getElementById('adm-cms-save').addEventListener('click', saveContent);
    refreshContentPreview();
  }

  function onContentDirty() {
    if (!contentState || contentState.dirty) return;
    contentState.dirty = true;
    var badge = document.getElementById('adm-cms-saved');
    if (badge) badge.hidden = true;
  }

  // 从表单收集当前值（以库中 value 为基底叠加，避免覆盖丢字段）
  function currentContentValue() {
    var row = selectedRow();
    var val = Object.assign({}, (row && row.value) || {});
    var schema = row ? (Array.isArray(row.schema) ? row.schema : []) : [];
    var root = document.getElementById('adm-cms-fields');
    if (!root) return val;
    schema.forEach(function (def) {
      val[def.name] = readContentField(root.querySelector('[data-fpath="' + def.name + '"]'), def);
    });
    return val;
  }

  function refreshContentPreview() {
    var box = document.getElementById('adm-cms-prev');
    var row = selectedRow();
    if (!box || !row) return;
    box.innerHTML = contentPreviewHtml(row);
  }

  function brandName() {
    if (contentState) {
      for (var i = 0; i < contentState.rows.length; i++) {
        if (contentState.rows[i].key === 'g_brand') {
          return (contentState.rows[i].value && contentState.rows[i].value.name) || 'SkillHub';
        }
      }
    }
    return 'SkillHub';
  }

  function contentPreviewHtml(row) {
    var v = currentContentValue();
    var t = contentMeta(row).preview || 'generic';
    if (t === 'brand') {
      return '<div class="adm-pv-browser"><div class="adm-pv-bar"><i></i><i></i><i></i></div>' +
        '<div class="adm-pv-brandhead"><span class="adm-pv-logo">' + esc(v.name || '品牌名称') + '</span>' +
        '<span class="adm-pv-brandlink"><b>' + esc(v.name || '') + '</b><i>' + esc(v.home_aria || '') + '</i></span></div></div>';
    }
    if (t === 'hero') {
      return '<div class="adm-pv-hero"><div class="adm-pv-hero-t">' + esc(v.title || '主标题') + '</div>' +
        (v.subtitle ? '<div class="adm-pv-hero-s">' + esc(v.subtitle) + '</div>' : '') +
        '<div class="adm-pv-hero-btns"><span class="adm-btn adm-btn-primary adm-btn-sm">' + esc(v.cta1_text || '主按钮') + '</span>' +
        '<span class="adm-btn adm-btn-sm">' + esc(v.cta2_text || '次按钮') + '</span></div></div>';
    }
    if (t === 'nav') {
      var items = Array.isArray(v.items) ? v.items : [];
      var links = items.map(function (it, i) {
        return '<span class="adm-pv-navlink' + (i === 0 ? ' is-act' : '') + '">' + esc(it.label || '') + '</span>';
      }).join('');
      return '<div class="adm-pv-browser"><div class="adm-pv-bar"><i></i><i></i><i></i></div>' +
        '<div class="adm-pv-navbar"><span class="adm-pv-logo">' + esc(brandName()) + '</span>' +
        '<nav class="adm-pv-navlinks">' + (links || '<span class="adm-pv-navlink">（暂无菜单项）</span>') + '</nav></div></div>';
    }
    if (t === 'footer') {
      var cols = Array.isArray(v.columns) ? v.columns : [];
      var colHtml = cols.map(function (c) {
        var ls = (Array.isArray(c.links) ? c.links : []).map(function (l) {
          return '<span class="adm-pv-flink">' + esc(l.label || '') + '</span>';
        }).join('');
        return '<div class="adm-pv-fcol"><b>' + esc(c.title || '') + '</b>' + ls + '</div>';
      }).join('');
      return '<div class="adm-pv-footer"><div class="adm-pv-fdesc">' + esc(v.desc || '') + '</div>' +
        '<div class="adm-pv-fcols">' + colHtml + '</div>' +
        '<div class="adm-pv-fcopy">' + esc(v.copyright || '') + '</div></div>';
    }
    if (t === 'meta') {
      return '<div class="adm-pv-serp"><div class="adm-pv-serp-site">' + esc(brandName()) + ' · skillhub.cn</div>' +
        '<div class="adm-pv-serp-t">' + esc(v.title || '页面标题') + '</div>' +
        '<div class="adm-pv-serp-d">' + esc(v.description || '页面描述将显示在这里。') + '</div></div>';
    }
    if (t === 'section') {
      return '<div class="adm-pv-section"><div class="adm-pv-sec-t">' + esc(v.title || '区块标题') + '</div>' +
        (v.subtitle ? '<div class="adm-pv-sec-s">' + esc(v.subtitle) + '</div>' : '') + '</div>';
    }
    if (t === 'page') {
      return '<div class="adm-pv-browser"><div class="adm-pv-bar"><i></i><i></i><i></i>' +
        '<span class="adm-pv-url">skillhub.cn</span></div>' +
        '<div class="adm-pv-page"><div class="adm-pv-page-t">' + esc(v.title || '页面标题') + '</div>' +
        (v.intro ? '<div class="adm-pv-page-d">' + esc(v.intro) + '</div>' : '') + '</div></div>';
    }
    var rowsHtml = Object.keys(v).map(function (k) {
      var val = (typeof v[k] === 'object' && v[k] !== null) ? JSON.stringify(v[k]) : String(v[k] == null ? '' : v[k]);
      if (val.length > 60) val = val.slice(0, 60) + '…';
      return '<div class="adm-pv-kv"><span>' + esc(k) + '</span><b>' + esc(val) + '</b></div>';
    }).join('');
    return '<div class="adm-pv-generic">' + (rowsHtml || '<span class="adm-mini">（暂无内容）</span>') + '</div>';
  }

  async function saveContent() {
    var row = selectedRow();
    if (!row) return;
    var schema = Array.isArray(row.schema) ? row.schema : [];
    var m = contentMeta(row);
    var root = document.getElementById('adm-cms-fields');
    if (!root) return;

    // 以库中既有 value 为基底，再按 schema 叠加本次表单值。
    // 若直接整体重建，value 中不在当前 schema 的字段会被静默删除（历史数据丢失）。
    var val = Object.assign({}, row.value || {});
    schema.forEach(function (def) {
      val[def.name] = readContentField(root.querySelector('[data-fpath="' + def.name + '"]'), def);
    });

    // 必填校验：为空则标红并阻止保存
    var firstBad = null;
    schema.forEach(function (def) {
      var fm = m.fields[def.name] || {};
      var v = val[def.name];
      var bad = !!fm.required && (v == null || (typeof v === 'string' && v.trim() === '') ||
        (Array.isArray(v) && !v.length));
      var node = root.querySelector('[data-fpath="' + def.name + '"]');
      if (node) node.classList.toggle('is-err', bad);
      if (bad && !firstBad) firstBad = def;
    });
    if (firstBad) {
      toast('请填写「' + (firstBad.label || firstBad.name) + '」后再保存', 'err');
      return;
    }

    try {
      var cl = await cloud();
      var up = await cl.database
        .from('site_content')
        .update({ value: val, updated_by: (state.session && state.session.user && state.session.user.id) || null })
        .eq('key', row.key)
        .select('key');
      if (up.error) throw up.error;
      if (!rowsOf(up).length) throw new Error('保存失败：当前账号没有写入权限。');
      row.value = val;
      row.updated_at = new Date().toISOString();
      await audit('编辑内容', 'site_content', row.key, row.title);
      // 通知可能打开的前台标签页立即刷新
      try { localStorage.setItem('skillhub_content_v1', JSON.stringify({ t: Date.now(), map: {} })); } catch (e) {}
      contentState.dirty = false;
      var badge = document.getElementById('adm-cms-saved');
      if (badge) badge.hidden = false;
      refreshContentPreview();
      toast('已保存「' + row.title + '」，前台已即时生效', 'ok');
    } catch (e) {
      toast(errText(e), 'err');
    }
  }

  function contentField(def, val, fm) {
    fm = fm || {};
    var wrap = document.createElement('div');
    wrap.className = 'adm-field';
    var lab = document.createElement('label');
    lab.innerHTML = esc(fm.label || def.label || def.name) + (fm.required ? ' <span class="adm-req">*</span>' : '');
    wrap.appendChild(lab);
    wrap.appendChild(renderContentControl(def, val));
    if (fm.help) {
      var help = document.createElement('p');
      help.className = 'adm-help';
      help.textContent = fm.help;
      wrap.appendChild(help);
    }
    return wrap;
  }

  function renderContentControl(def, val) {
    var node = document.createElement('div');
    node.setAttribute('data-fpath', def.name);
    if (def.type === 'list') {
      node.className = 'adm-list';
      var items = Array.isArray(val) ? val : [];
      items.forEach(function (it) { node.appendChild(renderListItem(def.item || [], it, def.item || [])); });
      var add = document.createElement('button');
      add.type = 'button';
      add.className = 'adm-btn adm-btn-sm';
      add.textContent = '+ 添加一项';
      add.addEventListener('click', function () {
        var blank = {};
        (def.item || []).forEach(function (s) { blank[s.name] = s.type === 'bool' ? false : ''; });
        node.insertBefore(renderListItem(def.item || [], blank, def.item || []), add);
      });
      node.appendChild(add);
      return node;
    }
    var input;
    if (def.type === 'textarea' || def.type === 'html' || def.type === 'lines') {
      input = document.createElement('textarea');
      input.className = 'adm-textarea';
      input.value = def.type === 'lines'
        ? (Array.isArray(val) ? val.join('\n') : (val == null ? '' : String(val)))
        : (val == null ? '' : String(val));
      if (def.type === 'html') input.classList.add('adm-textarea-mono');
      if (def.type === 'lines') input.rows = Math.max(3, (input.value.split('\n').length || 1));
    } else if (def.type === 'bool') {
      input = document.createElement('input');
      input.type = 'checkbox';
      input.checked = !!val;
      input.className = 'adm-check';
    } else if (def.type === 'number') {
      input = document.createElement('input');
      input.type = 'number';
      input.className = 'adm-input';
      input.value = val == null ? '' : val;
    } else if (def.type === 'image') {
      input = document.createElement('input');
      input.type = 'text';
      input.className = 'adm-input';
      input.placeholder = '图片 URL';
      input.value = val == null ? '' : String(val);
      var prev = document.createElement('div');
      prev.className = 'adm-img-prev';
      if (val) prev.innerHTML = '<img src="' + esc(String(val)) + '" alt="">';
      input.addEventListener('input', function () {
        prev.innerHTML = input.value ? '<img src="' + esc(input.value) + '" alt="">' : '';
      });
      node.appendChild(input);
      node.appendChild(prev);
      return node;
    } else {
      input = document.createElement('input');
      input.type = 'text';
      input.className = 'adm-input';
      input.value = val == null ? '' : String(val);
    }
    node.appendChild(input);
    return node;
  }

  function renderListItem(itemSchema, val, def) {
    var item = document.createElement('div');
    item.className = 'adm-list-item';
    (itemSchema || []).forEach(function (sub) {
      var subWrap = document.createElement('div');
      subWrap.className = 'adm-field';
      var l = document.createElement('label');
      l.textContent = sub.label || sub.name;
      subWrap.appendChild(l);
      subWrap.appendChild(renderContentControl(sub, val ? val[sub.name] : undefined));
      item.appendChild(subWrap);
    });
    var del = document.createElement('button');
    del.type = 'button';
    del.className = 'adm-btn adm-btn-sm adm-btn-danger';
    del.textContent = '删除';
    del.addEventListener('click', function () { item.remove(); });
    item.appendChild(del);
    return item;
  }

  function readContentField(node, def) {
    if (!node) return null;
    if (def.type === 'list') {
      var arr = [];
      node.querySelectorAll(':scope > .adm-list-item').forEach(function (item) {
        var obj = {};
        (def.item || []).forEach(function (sub) {
          obj[sub.name] = readContentField(item.querySelector(':scope > .adm-field [data-fpath="' + sub.name + '"]'), sub);
        });
        arr.push(obj);
      });
      return arr;
    }
    var ctrl = node.querySelector('input, textarea');
    if (def.type === 'bool') return !!ctrl.checked;
    if (def.type === 'number') return ctrl.value === '' ? null : Number(ctrl.value);
    if (def.type === 'lines') return String(ctrl.value).split('\n').filter(function (s) { return s !== ''; });
    return ctrl.value;
  }

  /* ------------------------- 路由 ------------------------- */

  var VIEWS = {
    overview: viewOverview,
    content_global: function () { return viewContent('global'); },
    content_sections: function () { return viewContent('sections'); },
    content_pages: function () { return viewContent('pages'); },
    skills: viewSkills,
    submissions: viewSubmissions,
    team: viewTeam,
    users: viewUsers,
    logs: viewLogs,
  };

  // 面包屑：分组 / 当前功能
  function crumbHtml() {
    var cur = NAV_INDEX[state.view];
    if (!cur) return '';
    return '<div class="adm-crumb"><span>' + esc(cur.group.label) + '</span>' +
      '<span class="sep">/</span><span class="cur">' + esc(cur.item.label) + '</span></div>';
  }

  async function paint() {
    if (!VIEWS[state.view]) state.view = 'overview';
    els.view.innerHTML = '<div class="adm-panel"><div class="adm-empty">加载中…</div></div>';
    await refreshPending();
    try {
      await VIEWS[state.view]();
      els.view.insertAdjacentHTML('afterbegin', crumbHtml());
    } catch (e) {
      els.view.innerHTML = '<div class="adm-panel"><div class="adm-msg is-err">' + esc(errText(e)) + '</div></div>';
    }
  }

  /* ------------------------- 启动 ------------------------- */

  function enterApp() {
    els.gate.style.display = 'none';
    els.app.style.display = 'grid';
    renderTopUser();
    var h = (location.hash || '').replace(/^#\/?/, '');
    if (VIEWS[h]) state.view = h;
    renderNav();
    paint();
  }

  async function init() {
    if (!C) {
      els.gate.style.display = 'flex';
      els.gateCard.innerHTML = '<h1>云服务未就绪</h1><p class="adm-sub">SDK 未加载，请刷新后重试。</p>';
      return;
    }
    try {
      var cb = await C.handleOAuthCallback();
      var session = (cb && cb.session) || (await C.getSession().catch(function () { return null; }));
      if (!session || !session.user) {
        showGate('guest');
        return;
      }
      state.session = session;
      var m = await myMembership(session.user.id).catch(function () { return null; });
      state.me = m;
      if (m && (m.role === 'admin' || m.role === 'super_admin')) enterApp();
      else if (m && m.role === 'pending') showGate('pending');
      else showGate('none');
    } catch (e) {
      els.gate.style.display = 'flex';
      els.gateCard.innerHTML = '<h1>初始化失败</h1><p class="adm-sub">' + esc(errText(e)) + '</p>';
    }
  }

  init();
})();
