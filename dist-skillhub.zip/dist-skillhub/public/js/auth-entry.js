/* ============================================================
   应用入口的 OAuth 回调处理
   ------------------------------------------------------------
   微信 / WorkBuddy 登录的回调地址必须是站点根路径（静态托管没有
    history fallback，子路径会先 404），所以回调落在 index.html。
   这里在页面启动、任何登录态判断之前先处理回调；普通访问不做任何
    网络请求，也不改动页面。
   ============================================================ */
(function () {
  'use strict';
  var C = window.SkillHubCloud;
  if (!C) return;

  C.handleOAuthCallback()
    .then(function (res) {
      if (res && res.handled && res.session) {
        // 登录成功后回到发布页
        window.location.replace('/publish.html');
      }
    })
    .catch(function () {
      /* 回调失败时保持首页原样，不打断浏览 */
    });
})();
