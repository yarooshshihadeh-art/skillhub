/* ============================================================
   导航「技能 / 探索」下拉菜单交互（1:1 复刻原站）
   ------------------------------------------------------------
   原站行为（实测）：
   - 点击触发（不是 hover）：aria-expanded false → true
   - 打开时按钮加 .nav-link-active，箭头 svg 加 .rotate-180
   - 面板是 React portal，挂在 body 层，class 为 .nav-mega-menu
   - 点页面空白处 / 按 Esc 关闭；同一时刻只开一个
   ============================================================ */
(function () {
  'use strict';

  var PANELS = window.SKILLHUB_NAV_PANELS || {};
  var GROUPS = [
    { key: 'skills', triggerId: 'nav-skills-trigger', menuId: 'nav-skills-menu' },
    { key: 'explore', triggerId: 'nav-explore-trigger', menuId: 'nav-explore-menu' },
  ];

  var menus = [];
  var current = null;

  function close() {
    menus.forEach(function (m) {
      m.panel.style.display = 'none';
      m.trigger.setAttribute('aria-expanded', 'false');
      m.trigger.classList.remove('nav-link-active');
      if (m.chevron) m.chevron.classList.remove('rotate-180');
    });
    current = null;
  }

  function open(m) {
    close();
    m.panel.style.display = '';
    m.trigger.setAttribute('aria-expanded', 'true');
    m.trigger.classList.add('nav-link-active');
    if (m.chevron) m.chevron.classList.add('rotate-180');
    current = m.key;
  }

  function toggle(m) {
    if (current === m.key) close();
    else open(m);
  }

  function init() {
    GROUPS.forEach(function (g) {
      var trigger = document.getElementById(g.triggerId);
      var html = PANELS[g.key];
      if (!trigger || !html) return;

      // 面板已存在（理论上不会）就复用，否则注入到 body（与原站 portal 一致）
      var panel = document.getElementById(g.menuId);
      if (!panel) {
        var wrap = document.createElement('div');
        wrap.innerHTML = html;
        panel = wrap.firstElementChild;
        if (!panel) return;
        document.body.appendChild(panel);
      }
      panel.style.display = 'none';

      var chevron = trigger.querySelector('svg');
      var m = { key: g.key, trigger: trigger, panel: panel, chevron: chevron };
      menus.push(m);

      trigger.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        toggle(m);
      });
      // 面板内点击不关闭（链接跳转由浏览器处理）
      panel.addEventListener('click', function (e) {
        e.stopPropagation();
      });
    });

    if (!menus.length) return;

    document.addEventListener('click', function () {
      if (current) close();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && current) close();
    });
    // 切换页面时复位
    window.addEventListener('pagehide', close);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
