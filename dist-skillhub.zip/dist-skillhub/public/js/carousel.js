/* ==========================================================================
   首页交互复刻（skillhub.cn）
   1) 英雄区折叠卡轮播：左右箭头点击切换 + 每 5s 自动切换 + 无障碍播报
   2) 企业案例分页：左右箭头 / 圆点切换 4 页企业卡片
   所有位置与时序均按原站 rAF 逐帧采样结果实现：
   - 槽位：-610 / 40 / 690 / 1340（卡片宽 634，间距 650）
   - 切换缓动：cubic-bezier(0.16, 1, 0.3, 1)，时长 1.4s
   - 自动切换间隔：5s
   ========================================================================== */
(function () {
  'use strict';

  /* ---------------- 英雄区折叠卡轮播 ---------------- */
  var cardEls = ['.sh-fold-1', '.sh-fold-2', '.sh-fold-3']
    .map(function (sel) { return document.querySelector(sel); })
    .filter(Boolean);

  if (cardEls.length === 3) {
    var SLOT_OUT = -610;   // 左侧屏外
    var SLOT_CUR = 40;     // 当前卡
    var SLOT_MID = 690;    // 中间
    var SLOT_NEXT = 1340;  // 右侧屏外/预览位
    var STEP = 650;
    var INTERVAL = 5000;   // 原站自动切换间隔

    var TITLES = [
      'DeepSeek Harness Plugin 广场',
      'SkillPay：企业服务按调用计费',
      '企业专区：认证企业与官方 Skills'
    ];

    var host = cardEls[0].parentElement || document.body;
    var preview = document.querySelector('.sh-fold-preview');
    var liveEl = document.querySelector('p.sr-only[aria-live="polite"]');
    var pos = [SLOT_CUR, SLOT_MID, SLOT_NEXT];
    var ready = false;
    var timer = null;

    function tx(x) { return 'translateX(' + x + 'px)'; }

    function setX(el, x) { el.style.transform = tx(x); }

    /* 入场动画结束后交给 JS：必须移除 animation，否则 forwards 填充会一直
       覆盖内联 transform（此前"点击无法切换"的根因） */
    function markReady() {
      if (ready) return;
      ready = true;
      document.documentElement.classList.add('sh-anim-done', 'sh-carousel-ready');
      cardEls.forEach(function (el, i) { setX(el, pos[i]); });
    }

    if (cardEls[0].addEventListener) {
      cardEls[2].addEventListener('animationend', markReady, { once: true });
    }

    /* 入场动画的播放时机
       ------------------------------------------------------------
       CSS 里动画是 paused 的（停在 0% 叠牌帧）。这里等到「首屏真的画出来了」
       再开始播放：连续两帧 rAF（第二帧意味着前一帧已经绘制），并且页面必须可见。
       否则首屏被外链脚本 / 字体 / 图片拖慢时，3.2s 动画会在用户看到页面之前跑完。 */
    var foldStarted = false;

    function startFold() {
      if (foldStarted) return;
      foldStarted = true;
      cardEls.forEach(function (el) { el.classList.add('sh-fold-go'); });
      // 动画结束（或两个兜底时机）后交给 JS 接管并启动自动轮播
      setTimeout(markReady, 3400);
      setTimeout(function () { updateLive(); schedule(); }, 3400);
    }

    function tryStart() {
      if (foldStarted) return;
      if (document.visibilityState === 'hidden') return; // 后台标签页等可见再播
      startFold();
    }

    function afterPaint() {
      requestAnimationFrame(function () { requestAnimationFrame(tryStart); });
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', afterPaint);
    } else {
      afterPaint();
    }
    document.addEventListener('visibilitychange', tryStart);
    setTimeout(tryStart, 2500); // 兜底：任何原因没触发也保证播放

    function zOf(i) {
      var z = cardEls[i].style.zIndex;
      return z ? z : String(30 - i * 10);
    }

    /* 预览卡：显示"刚从左侧移出"的那张卡的内容（原站 1340 处的置灰副本） */
    function showPreview(srcIdx) {
      if (!preview || srcIdx < 0) return;
      preview.innerHTML = cardEls[srcIdx].innerHTML;
      preview.style.zIndex = zOf(srcIdx);
      preview.style.transform = tx(SLOT_NEXT);
      preview.classList.add('sh-show');
    }

    function hidePreview() {
      if (preview) preview.classList.remove('sh-show');
    }

    function updateLive() {
      if (!liveEl) return;
      var idx = pos.indexOf(SLOT_CUR);
      if (idx >= 0) liveEl.textContent = '当前卡片：' + TITLES[idx];
    }

    function schedule() {
      if (timer) clearTimeout(timer);
      timer = setTimeout(function () { next(); }, INTERVAL);
    }

    function next() {
      markReady();
      var outIdx = pos.indexOf(SLOT_CUR);   // 即将移出左侧的卡 → 作为右侧预览
      var jumpIdx = pos.indexOf(SLOT_OUT);  // 位于屏外的卡 → 绕回右侧进场
      hidePreview();
      if (outIdx >= 0) showPreview(outIdx);
      cardEls.forEach(function (el, i) {
        if (i === jumpIdx) {
          // 瞬移到 1340，再滑入 690（视觉上从右侧进场）
          el.style.transition = 'none';
          setX(el, SLOT_NEXT);
          void el.offsetWidth;
          el.style.transition = '';
          pos[i] = SLOT_MID;
          setX(el, SLOT_MID);
        } else {
          pos[i] = pos[i] - STEP;
          setX(el, pos[i]);
        }
      });
      updateLive();
      schedule();
    }

    function prev() {
      markReady();
      var jumpIdx = pos.indexOf(SLOT_NEXT); // 位于 1340 的卡 → 绕回左侧
      hidePreview();
      cardEls.forEach(function (el, i) {
        if (i === jumpIdx) {
          el.style.transition = 'none';
          setX(el, SLOT_OUT);
          void el.offsetWidth;
          el.style.transition = '';
          pos[i] = SLOT_CUR;
          setX(el, SLOT_CUR);
        } else {
          pos[i] = pos[i] + STEP;
          setX(el, pos[i]);
        }
      });
      updateLive();
      schedule();
    }

    var prevBtn = document.querySelector('button[aria-label="上一张卡片"]');
    var nextBtn = document.querySelector('button[aria-label="下一张卡片"]');
    if (prevBtn) prevBtn.addEventListener('click', function (e) { e.preventDefault(); prev(); });
    if (nextBtn) nextBtn.addEventListener('click', function (e) { e.preventDefault(); next(); });

    // 调试接口
    window.__heroCarousel = { next: next, prev: prev, pos: pos, isReady: function () { return ready; } };
  }

  /* ---------------- 企业案例分页 ---------------- */
  var pager = document.querySelector('[aria-label="企业案例分页"]');
  var pages = window.ENTERPRISE_PAGES || [];
  if (pager && pages.length) {
    var firstCard = document.querySelector('a[dt-eid="home-enterprise-card"]');
    var grid = firstCard ? firstCard.parentElement : null;
    var prevEnt = pager.querySelector('button[aria-label="上一页企业"]');
    var nextEnt = pager.querySelector('button[aria-label="下一页企业"]');
    var dots = Array.prototype.slice.call(pager.querySelectorAll('button[aria-label^="第 "]'));
    var EASE = 'cubic-bezier(0.16, 1, 0.3, 1)';
    var DUR = 460;
    var page = 0;
    var busy = false;

    if (grid) {
      grid.style.transition = 'opacity ' + DUR + 'ms ' + EASE + ', transform ' + DUR + 'ms ' + EASE;
    }

    function render(i) {
      var p = pages[i];
      if (!p || !grid) return;
      grid.className = p.gridClass;
      grid.innerHTML = p.html;
      dots.forEach(function (d, k) {
        var on = k === i;
        d.className = 'cursor-pointer rounded-full border-none transition-all duration-200 ' +
          (on ? 'h-2 w-5 bg-black' : 'h-2 w-2 bg-black/20 hover:bg-black/40');
        if (on) d.setAttribute('aria-current', 'page');
        else d.removeAttribute('aria-current');
      });
      if (prevEnt) prevEnt.disabled = i === 0;
      if (nextEnt) nextEnt.disabled = i === pages.length - 1;
    }

    function go(i) {
      if (busy || !grid || i === page || i < 0 || i >= pages.length) return;
      busy = true;
      var dir = i > page ? -1 : 1;   // 前进：旧页向左滑出，新页从右滑入
      grid.style.opacity = '0';
      grid.style.transform = 'translateX(' + dir * 30 + 'px)';
      setTimeout(function () {
        page = i;
        render(page);
        grid.style.transition = 'none';
        grid.style.transform = 'translateX(' + -dir * 30 + 'px)';
        grid.style.opacity = '0';
        void grid.offsetWidth;
        grid.style.transition = 'opacity ' + DUR + 'ms ' + EASE + ', transform ' + DUR + 'ms ' + EASE;
        grid.style.transform = 'translateX(0px)';
        grid.style.opacity = '1';
        setTimeout(function () { busy = false; }, DUR);
      }, DUR);
    }

    if (prevEnt) prevEnt.addEventListener('click', function () { go(page - 1); });
    if (nextEnt) nextEnt.addEventListener('click', function () { go(page + 1); });
    dots.forEach(function (d, k) {
      d.addEventListener('click', function () { go(k); });
    });

    window.__enterprisePager = { go: go, getPage: function () { return page; } };
  }

  /* ---------------- 排行榜标签（近期飙升 / 下载热榜） ---------------- */
  var tabTrend = document.getElementById('home-ranking-tab-trending');
  var tabHot = document.getElementById('home-ranking-tab-hot');
  var panelTrend = document.getElementById('home-ranking-panel-trending');
  var panelHot = document.getElementById('home-ranking-panel-hot');
  if (tabTrend && tabHot && panelTrend && panelHot) {
    var TAB_BASE = 'relative pb-3 text-[15px] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black/30 focus-visible:ring-offset-4 ';
    var TAB_ON = TAB_BASE + 'font-medium text-black';
    var TAB_OFF = TAB_BASE + 'text-black/40 hover:text-black/70';
    var UNDERLINE = '<span class="absolute inset-x-0 bottom-[-1px] h-0.5 bg-black" aria-hidden="true"></span>';
    var more = document.querySelector('[dt-eid="home-ranking-more"]');
    var MORE = {
      trending: { href: '/skills.html?sort=trending', label: '查看更多近期飙升技能', remark: 'tab=trending' },
      hot: { href: '/skills?sortBy=downloads', label: '查看更多下载热榜技能', remark: 'tab=hot' }
    };

    function selectTab(which) {
      var isTrend = which === 'trending';
      var on = isTrend ? tabTrend : tabHot;
      var off = isTrend ? tabHot : tabTrend;
      var label = isTrend ? '近期飙升' : '下载热榜';

      on.className = TAB_ON;
      on.setAttribute('aria-selected', 'true');
      on.innerHTML = label + UNDERLINE;
      off.className = TAB_OFF;
      off.setAttribute('aria-selected', 'false');
      off.textContent = isTrend ? '下载热榜' : '近期飙升';

      panelTrend.classList.toggle('hidden', !isTrend);
      panelHot.classList.toggle('hidden', isTrend);

      if (more) {
        var cfg = MORE[which];
        more.setAttribute('href', cfg.href);
        more.setAttribute('aria-label', cfg.label);
        more.setAttribute('dt-remark', cfg.remark);
      }
    }

    tabTrend.addEventListener('click', function () { selectTab('trending'); });
    tabHot.addEventListener('click', function () { selectTab('hot'); });
    window.__rankingTabs = { select: selectTab };
  }
})();
