/* ============================================================
   发布页云端逻辑
   ------------------------------------------------------------
   未登录：原封不动保留原站「需要登录才能访问」的 1:1 外观，
           并把「登录 / 注册」按钮指向真实云登录页。
   已登录：显示云端发布面板 —— 上传 Skill 包到云存储、
           写入云端数据库、列出「我的发布」并支持删除。
   ============================================================ */
(function () {
  'use strict';

  var C = window.SkillHubCloud;
  var root = document.getElementById('cloud-publish-root');
  var gateMain = document.querySelector('main.flex-1.flex.flex-col');
  var msg = document.getElementById('cp-msg');

  var state = { session: null, busy: false };

  function say(text, kind) {
    if (!msg) return;
    msg.textContent = text || '';
    msg.style.color = kind === 'ok' ? '#067647' : kind === 'err' ? '#D92D20' : 'rgba(0,0,0,.55)';
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function fmtSize(n) {
    if (!n) return '—';
    if (n < 1024) return n + ' B';
    if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
    return (n / 1024 / 1024).toFixed(2) + ' MB';
  }

  /* 未登录：把登录入口接到真实登录页 */
  function bindGuestEntries() {
    var btn = document.querySelector('main button.inline-flex');
    if (btn) {
      btn.addEventListener('click', function () {
        window.location.href = '/login.html';
      });
    }
    document.querySelectorAll('.nav-login-btn').forEach(function (b) {
      b.addEventListener('click', function (e) {
        e.preventDefault();
        window.location.href = '/login.html';
      });
    });
  }

  /* 已登录：切换到云端面板 */
  function enterApp(session) {
    state.session = session;
    if (gateMain) gateMain.style.display = 'none';
    if (root) root.style.display = 'block';

    var u = session.user || {};
    var name = u.name || '（未设置昵称）';
    document.getElementById('cp-user').innerHTML =
      '<div style="display:flex;align-items:center;gap:12px">' +
      '<div style="width:40px;height:40px;border-radius:50%;background:#3957FF;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:600">' +
      esc(String(name).charAt(0).toUpperCase()) +
      '</div><div><div style="font-size:15px;font-weight:500;color:#000">' +
      esc(name) +
      '</div><div style="font-size:12px;color:rgba(0,0,0,.5)">' +
      esc(String(u.id || '').slice(0, 12)) +
      '…</div></div>' +
      '<button id="cp-out" type="button" style="margin-left:auto;background:none;border:1px solid #E5E5E5;border-radius:8px;padding:6px 12px;font-size:13px;cursor:pointer;color:#000">退出登录</button></div>';

    document.getElementById('cp-out').addEventListener('click', async function () {
      await C.signOut().catch(function () {});
      window.location.reload();
    });

    Promise.all([loadCatalog(), loadMine()]).catch(function (e) {
      say(C.friendlyError(e), 'err');
    });
  }

  /* 读云端技能目录（公共读，验证数据库可用） */
  async function loadCatalog() {
    var box = document.getElementById('cp-stats');
    try {
      var total = await C.countCatalogSkills();
      var rows = await C.listCatalogSkills(6);
      var html =
        '<div style="display:flex;gap:20px;align-items:baseline;flex-wrap:wrap;margin-bottom:10px">' +
        '<div style="font-size:28px;font-weight:500;color:#000">' +
        total +
        '</div><div style="font-size:13px;color:rgba(0,0,0,.55)">云端技能库总数（数据库实时读取）</div></div>';
      if (rows.length) {
        html += '<div style="font-size:13px;color:rgba(0,0,0,.55);margin-bottom:6px">下载量最高的技能：</div><ul style="margin:0;padding-left:18px;font-size:13px;color:rgba(0,0,0,.8);line-height:22px">';
        rows.forEach(function (r) {
          html +=
            '<li>' +
            esc(r.icon || '') +
            ' ' +
            esc(r.name) +
            ' · ' +
            esc(r.author || '') +
            ' · ' +
            esc(r.downloads) +
            ' 次下载</li>';
        });
        html += '</ul>';
      }
      box.innerHTML = html;
    } catch (e) {
      box.innerHTML = '<div style="font-size:13px;color:#D92D20">云端技能库读取失败：' + esc(C.friendlyError(e)) + '</div>';
    }
  }

  /* 读「我的发布」（RLS 按 owner 隔离） */
  async function loadMine() {
    var box = document.getElementById('cp-mine');
    try {
      var rows = await C.listMySubmissions();
      if (!rows.length) {
        box.innerHTML = '<div style="font-size:13px;color:rgba(0,0,0,.45)">你还没有发布过 Skill。</div>';
        return;
      }
      var html =
        '<div style="font-size:14px;font-weight:500;color:#000;margin-bottom:8px">我的发布（' +
        rows.length +
        '）</div>';
      rows.forEach(function (r) {
        html +=
          '<div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-top:1px solid #F0F0F0">' +
          '<div style="flex:1;min-width:0"><div style="font-size:14px;color:#000">' +
          esc(r.title) +
          '</div><div style="font-size:12px;color:rgba(0,0,0,.5)">' +
          esc(r.category || '未分类') +
          ' · ' +
          esc(r.file_name || '无附件') +
          ' ' +
          esc(fmtSize(r.file_size)) +
          ' · ' +
          esc(String(r.created_at || '').slice(0, 10)) +
          '</div></div>' +
          '<button data-del="' +
          esc(r.id) +
          '" type="button" style="background:none;border:1px solid #E5E5E5;border-radius:8px;padding:5px 10px;font-size:12px;cursor:pointer;color:#D92D20">删除</button></div>';
      });
      box.innerHTML = html;
      box.querySelectorAll('button[data-del]').forEach(function (b) {
        b.addEventListener('click', function () {
          onDelete(parseInt(b.getAttribute('data-del'), 10));
        });
      });
    } catch (e) {
      box.innerHTML = '<div style="font-size:13px;color:#D92D20">读取我的发布失败：' + esc(C.friendlyError(e)) + '</div>';
    }
  }

  async function onDelete(id) {
    if (state.busy) return;
    state.busy = true;
    say('正在删除…');
    try {
      var ok = await C.removeSubmission(id);
      say(ok ? '已删除。' : '删除失败：记录不存在或不属于当前账号。', ok ? 'ok' : 'err');
      await loadMine();
    } catch (e) {
      say(C.friendlyError(e), 'err');
    } finally {
      state.busy = false;
    }
  }

  /* 发布：上传文件 → 写库 */
  async function onSubmit(ev) {
    ev.preventDefault();
    if (state.busy) return;
    var title = document.getElementById('cp-title').value.trim();
    var summary = document.getElementById('cp-summary').value.trim();
    var category = document.getElementById('cp-category').value;
    var fileInput = document.getElementById('cp-file');
    var file = fileInput && fileInput.files && fileInput.files[0];

    if (!title) {
      say('请填写 Skill 名称。', 'err');
      return;
    }
    if (file) {
      var okExt = /\.(zip|md|txt|json|yaml|yml)$/i.test(file.name);
      if (!okExt) {
        say('仅支持 .zip / .md / .txt / .json / .yaml 文件。', 'err');
        return;
      }
      if (file.size > 5 * 1024 * 1024) {
        say('文件不能超过 5MB。', 'err');
        return;
      }
    }

    state.busy = true;
    var btn = document.getElementById('cp-submit');
    btn.disabled = true;
    btn.textContent = '发布中…';
    try {
      var storedPath = null;
      if (file) {
        say('正在上传 Skill 包到云存储…');
        storedPath = await C.uploadSkillFile(state.session, file);
      }
      say('正在写入云端数据库…');
      var row = {
        title: title,
        summary: summary || null,
        category: category,
        file_path: storedPath,
        file_name: file ? file.name : null,
        file_size: file ? file.size : null,
        status: 'pending',
      };
      // owner_id 不传：由 DEFAULT auth.uid() + RLS 决定归属
      var created = await C.createSubmission(row);
      say(created ? '发布成功，已保存到云端。' : '发布失败：数据库未返回记录。', created ? 'ok' : 'err');
      document.getElementById('cp-title').value = '';
      document.getElementById('cp-summary').value = '';
      if (fileInput) fileInput.value = '';
      await loadMine();
    } catch (e) {
      say(C.friendlyError(e), 'err');
    } finally {
      state.busy = false;
      btn.disabled = false;
      btn.textContent = '发布到云端';
    }
  }

  async function init() {
    if (!root) return;
    var form = document.getElementById('cp-form');
    if (form) form.addEventListener('submit', onSubmit);

    var cb = await C.handleOAuthCallback();
    if (cb && cb.error) say(cb.error, 'err');
    var session = (cb && cb.session) || (await C.getSession().catch(function () { return null; }));
    if (session && session.user) enterApp(session);
    else bindGuestEntries();
  }

  init().catch(function (e) {
    say(C.friendlyError(e), 'err');
  });
})();
