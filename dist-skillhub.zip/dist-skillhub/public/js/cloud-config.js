/* ============================================================
   云服务配置
   ------------------------------------------------------------
   这四项是唯一允许出现在前端代码里的公开配置：
   它们只用于标识应用、路由请求，本身不构成凭据，
   真正的权限控制由服务端 RLS 策略负责。

   ⚠️ 这里保留的是一套「演示用后端」配置，克隆后可直接看到完整数据；
      接入自己的后端时请替换成你在云平台创建应用后拿到的值。
      注意 endpoint 必须与服务端校验的 Origin 完全一致，
      不能改成 location.origin 或其它域名，否则请求会被拒绝。
   ============================================================ */
window.SKILLHUB_PUBLIC_CONFIG = {
  resourceId: 'wbcs_1L89EQxlHIXkklrA0L7Dmp',
  endpoint: 'https://rea-website-93846.app.workbuddy.host',
  oauthRelayBaseUrl: 'https://www.workbuddy.cn/v2/as/genie-baas/oauth',
  publishableKey: 'wbpk_eq59Ul8k23tguEWE60qh4R_BzsR5FAaZrj8i1plPcIPNxI9gL2Etulf',
};
