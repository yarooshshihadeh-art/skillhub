/* ============================================================
   滚动进场揭示动画（1:1 复刻原站）
   ------------------------------------------------------------
   原站实测：首屏加载时有 12 个区块处于
     opacity: 0; transform: translateY(24 / 32 / 36 / 48px)
   滚动到「元素顶部进入视口 ~88%」位置时揭示为
     opacity: 1; transform: translateY(0px)
   过渡曲线与时长已写在各元素的内联 style 里（0.75~0.9s，
   cubic-bezier(0.16,1,0.3,1)，部分带 100/120ms 延迟），
   所以这里只负责在正确时机翻转 opacity / transform。
   索引取自原站 DOM 顺序（[style*="opacity"] 第 N 个）。
   ============================================================ */
(function () {
  'use strict';

  // 索引 → 初始位移量（px）
  var HIDDEN = { 46: 48, 47: 48, 48: 48, 51: 48, 52: 24, 53: 24, 54: 48, 55: 48, 56: 36, 57: 36, 59: 48, 60: 32 };
  var TOTAL = 62; // 原站 [style*="opacity"] 元素总数，用作结构校验
  var LINE = 0.88; // 视口高度占比：元素顶部越过这条线即揭示

  function init() {
    var els = document.querySelectorAll('[style*="opacity"]');
    // 结构变了就不动，避免把不该隐藏的元素藏起来
    if (els.length !== TOTAL) return;

    var pending = [];
    Object.keys(HIDDEN).forEach(function (k) {
      var el = els[Number(k)];
      if (!el) return;
      el.style.opacity = '0';
      el.style.transform = 'translateY(' + HIDDEN[k] + 'px)';
      pending.push(el);
    });
    if (!pending.length) return;

    var ticking = false;
    function check() {
      var h = window.innerHeight || document.documentElement.clientHeight || 800;
      for (var i = pending.length - 1; i >= 0; i--) {
        var r = pending[i].getBoundingClientRect();
        if (r.top < h * LINE) {
          pending[i].style.opacity = '1';
          pending[i].style.transform = 'translateY(0px)';
          pending.splice(i, 1);
        }
      }
      if (!pending.length) window.removeEventListener('scroll', onScroll);
    }
    function onScroll() {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(function () {
        ticking = false;
        check();
      });
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    check();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
