/* ============================================================
   登录页逻辑 —— 手机号 / 邮箱验证码登录 + 微信登录
   ------------------------------------------------------------
   规则：
   - 发送验证码与提交验证码是两个独立动作；提交时复用已保存的 challenge，
     绝不再次发送。
   - 手机号按中国大陆号码校验：11 位且以 1 开头。
   - OTP 免密注册/登录，不收集密码。
   - 进入页面先处理 OAuth 回调（要早于任何登录态判断）。
   ============================================================ */
(function () {
  'use strict';

  var C = window.SkillHubCloud;
  var mode = 'phone'; // phone | email
  var pending = null; // { kind, value, verificationId, isExistingUser }
  var sending = false;
  var submitting = false;
  var countdown = 0;

  // 登录成功后要回跳的目标页（例如从 /admin.html 过来必须原路返回）
  var BACK = (function () {
    var v = '';
    try {
      v = new URLSearchParams(window.location.search).get('redirect') || '';
    } catch (e) {
      v = '';
    }
    return v && v.charAt(0) === '/' && v.indexOf('//') !== 0 ? v : '';
  })();

  var $ = function (id) {
    return document.getElementById(id);
  };
  var el = {
    guest: $('guest-view'),
    signed: $('signed-view'),
    tabPhone: $('tab-phone'),
    tabEmail: $('tab-email'),
    acct: $('acct'),
    acctLabel: $('acct-label'),
    acctErr: $('acct-err'),
    code: $('code'),
    btnCode: $('btn-code'),
    btnSubmit: $('btn-submit'),
    btnWx: $('btn-wx'),
    btnOut: $('btn-out'),
    msg: $('msg'),
    uName: $('u-name'),
    uId: $('u-id'),
    uAv: $('u-av'),
  };

  function say(text, kind) {
    el.msg.textContent = text || '';
    el.msg.className = 'msg' + (kind ? ' ' + kind : '');
  }

  function setMode(next) {
    mode = next;
    pending = null;
    el.acctErr.textContent = '';
    el.code.value = '';
    say('');
    el.tabPhone.setAttribute('aria-pressed', String(next === 'phone'));
    el.tabEmail.setAttribute('aria-pressed', String(next === 'email'));
    if (next === 'phone') {
      el.acctLabel.textContent = '手机号';
      el.acct.setAttribute('placeholder', '请输入 11 位手机号');
      el.acct.setAttribute('inputmode', 'numeric');
      el.acct.setAttribute('autocomplete', 'tel');
      el.acct.setAttribute('type', 'text');
    } else {
      el.acctLabel.textContent = '邮箱';
      el.acct.setAttribute('placeholder', 'name@example.com');
      el.acct.setAttribute('inputmode', 'email');
      el.acct.setAttribute('autocomplete', 'email');
      el.acct.setAttribute('type', 'email');
    }
  }

  function validate() {
    var v = el.acct.value.trim();
    if (mode === 'phone') {
      if (!/^1\d{10}$/.test(v)) {
        el.acctErr.textContent = '请输入正确的 11 位手机号';
        return null;
      }
      return v; // 原样传给 SDK，SDK 自行做 +86 规范化
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) {
      el.acctErr.textContent = '请输入正确的邮箱地址';
      return null;
    }
    return v;
  }

  function tickCountdown() {
    if (countdown > 0) {
      el.btnCode.textContent = countdown + ' 秒后重发';
      el.btnCode.disabled = true;
      countdown -= 1;
      setTimeout(tickCountdown, 1000);
      return;
    }
    el.btnCode.textContent = '获取验证码';
    el.btnCode.disabled = sending;
  }

  async function onSend() {
    if (sending) return;
    var value = validate();
    if (!value) return;
    el.acctErr.textContent = '';
    sending = true;
    el.btnCode.disabled = true;
    say('正在发送验证码…');
    try {
      var res = mode === 'phone' ? await C.sendPhoneCode(value) : await C.sendEmailCode(value);
      if (res && res.error) {
        say(C.friendlyError(res.error), 'e');
        return;
      }
      pending = {
        kind: mode,
        value: value,
        verificationId: res.data.verificationId,
        isExistingUser: res.data.isExistingUser,
      };
      countdown = 60;
      say('验证码已发送，请查收。', 'o');
      tickCountdown();
    } catch (e) {
      say(C.friendlyError(e), 'e');
    } finally {
      sending = false;
      if (countdown === 0) el.btnCode.disabled = false;
    }
  }

  async function onSubmit() {
    if (submitting) return;
    var value = el.acct.value.trim();
    var token = el.code.value.trim();
    if (!pending || pending.kind !== mode || pending.value !== value) {
      say('请先为当前账号获取验证码。', 'e');
      return;
    }
    if (!token) {
      say('请输入验证码。', 'e');
      return;
    }
    submitting = true;
    el.btnSubmit.disabled = true;
    say('正在验证…');
    try {
      var res =
        mode === 'phone'
          ? await C.verifyPhoneCode(pending.value, pending.verificationId, pending.isExistingUser, token)
          : await C.verifyEmailCode(pending.value, pending.verificationId, pending.isExistingUser, token);
      if (res && res.error) {
        say(C.friendlyError(res.error), 'e');
        return;
      }
      pending = null;
      el.code.value = '';
      renderSigned(res.data && res.data.user);
      say('登录成功。', 'o');
      goBack();
    } catch (e) {
      say(C.friendlyError(e), 'e');
    } finally {
      submitting = false;
      el.btnSubmit.disabled = false;
    }
  }

  function initials(name) {
    if (!name) return 'U';
    var s = String(name).trim();
    return s.charAt(0).toUpperCase();
  }

  function goBack() {
    if (!BACK) return;
    setTimeout(function () {
      window.location.href = BACK;
    }, 600);
  }

  function renderSigned(user) {
    if (!user) return;
    el.guest.style.display = 'none';
    el.signed.style.display = 'block';
    el.uName.textContent = user.name || '（未设置昵称）';
    el.uId.textContent = '用户 ID：' + String(user.id || '').slice(0, 10) + '…';
    el.uAv.textContent = initials(user.name);
  }

  function renderGuest() {
    el.guest.style.display = 'block';
    el.signed.style.display = 'none';
  }

  async function init() {
    el.tabPhone.addEventListener('click', function () {
      setMode('phone');
    });
    el.tabEmail.addEventListener('click', function () {
      setMode('email');
    });
    el.acct.addEventListener('input', function () {
      el.acctErr.textContent = '';
    });
    el.btnCode.addEventListener('click', onSend);
    el.btnSubmit.addEventListener('click', onSubmit);
    el.btnWx.addEventListener('click', function () {
      el.btnWx.disabled = true;
      C.signInWithWeChat(BACK).catch(function (e) {
        el.btnWx.disabled = false;
        say(C.friendlyError(e), 'e');
      });
    });
    el.btnOut.addEventListener('click', async function () {
      await C.signOut().catch(function () {});
      renderGuest();
      say('已退出登录。');
    });

    // 回调必须早于登录态判断
    var cb = await C.handleOAuthCallback();
    if (cb && cb.error) {
      say(cb.error, 'e');
    }
    var session = (cb && cb.session) || (await C.getSession().catch(function () { return null; }));
    if (session && session.user) {
      renderSigned(session.user);
      goBack();
    } else renderGuest();

    C.onChange(function (event, s) {
      if (s && s.user) {
        renderSigned(s.user);
        if (event !== 'INITIAL_SESSION') goBack();
      } else renderGuest();
    });
  }

  init().catch(function (e) {
    say(C.friendlyError(e), 'e');
  });
})();
