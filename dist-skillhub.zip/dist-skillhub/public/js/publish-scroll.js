/* ============================================================
   首页「把专业能力，发布成可信的 Skill」区块 —— 滚动驱动展开/收拢
   ------------------------------------------------------------
   原站机制（无头浏览器滚动采样还原）：
   - 区块高 1432px，内部 sticky 容器 top:200px、高 460px（左文案 + 右 4 张叠板）
   - 4 张卡片绝对定位，各高 340px，初始为「展开态」：
       translateY = 0 / 364 / 728 / 1092  背景统一 #F5F5F5
     （展开态总跨度 1092 + 340 = 1432 = 区块高，正好填满整块）
   - 当区块顶部滚到视口 200px（即 sticky 吸附）时开始「逐张收拢」，
     行程 RANGE = 区块高 - sticky 高 = 972px，收拢到：
       translateY = 0 / 40 / 80 / 120     背景 #DDD / #E5E5E5 / #EDEDED / #F5F5F5
   - 同步：卡片 2/3/4 各自收拢到位时（progress 324 / 648 / 972），
     左侧步骤列表依次点亮第 1→2→3→4 项
   - 色值随 progress 线性变暗：delta_i = 24 * clamp(progress - 324*i, 0, 972 - 324*i) / 972
   ============================================================ */
(function () {
  'use strict';

  var BASE = [0, 364, 728, 1092]; // 展开态
  var TARGET = [0, 40, 80, 120]; // 收拢态
  var STEP_LABELS = ['实名认证', '安全与内容审核', '强制安全准入', '网页、CLI 与 Agent 发布'];
  var BASE_BG = 245; // #F5F5F5

  var DOT_IDLE = 'w-1.5 h-1.5 rounded-full shrink-0 transition-all duration-300 bg-black/15';
  var DOT_ACTIVE = 'w-1.5 h-1.5 rounded-full shrink-0 transition-all duration-300 bg-black';
  var LABEL_IDLE = 'text-[15px] transition-colors duration-300 text-black/40';
  var LABEL_ACTIVE = 'text-[15px] transition-colors duration-300 font-semibold text-black';

  function pickSection() {
    var secs = document.querySelectorAll('section');
    for (var i = 0; i < secs.length; i++) {
      var s = secs[i];
      if (
        s.className.indexOf('md:block') !== -1 &&
        s.textContent.indexOf('把专业能力') !== -1
      ) {
        return s;
      }
    }
    return null;
  }

  function init() {
    var sec = pickSection();
    if (!sec) return;

    var sticky = sec.firstElementChild;
    var rightCol = sec.querySelector('div[class*="w-[60%]"]');
    if (!sticky || !rightCol) return;

    var panels = [].slice.call(rightCol.children).filter(function (el) {
      return el.style && /translateY/.test(el.style.transform || '') === true;
    });
    if (panels.length < 4) {
      panels = [].slice.call(rightCol.children).slice(0, 4);
    }
    if (panels.length !== 4) return;

    // 左列 4 个步骤行
    var stepRows = [];
    STEP_LABELS.forEach(function (lbl) {
      var divs = sec.querySelectorAll('div');
      for (var i = 0; i < divs.length; i++) {
        var d = divs[i];
        if (d.children.length === 2 && (d.textContent || '').trim() === lbl) {
          stepRows.push(d);
          break;
        }
      }
    });

    var RANGE = sec.offsetHeight - sticky.offsetHeight; // 972
    var STICKY_TOP = parseFloat(window.getComputedStyle(sticky).top) || 200;
    if (!(RANGE > 0)) RANGE = 972;

    var lastStep = -1;
    var ticking = false;

    function clamp(v, lo, hi) {
      return v < lo ? lo : v > hi ? hi : v;
    }

    function applyStep(idx) {
      if (idx === lastStep) return;
      lastStep = idx;
      for (var i = 0; i < stepRows.length; i++) {
        var row = stepRows[i];
        var dot = row.children[0];
        var label = row.children[1];
        var on = i === idx;
        if (dot && dot.className !== undefined) dot.className = on ? DOT_ACTIVE : DOT_IDLE;
        if (label && label.className !== undefined) label.className = on ? LABEL_ACTIVE : LABEL_IDLE;
      }
    }

    function update() {
      ticking = false;
      var top = sec.getBoundingClientRect().top;
      var progress = clamp(STICKY_TOP - top, 0, RANGE);

      for (var i = 0; i < 4; i++) {
        // 位置：展开态随进度向上收拢，到 TARGET 封顶
        var y = clamp(BASE[i] - progress, TARGET[i], BASE[i]);
        // 颜色：卡片收拢到位后开始变暗，到 RANGE 时达到自身最终色
        var start = (RANGE / 3) * i; // 0 / 324 / 648 / 972
        var span = RANGE - start; // 972 / 648 / 324 / 0
        var delta = span > 0 ? (24 / RANGE) * clamp(progress - start, 0, span) : 0;
        var v = Math.round(BASE_BG - delta);
        panels[i].style.transform = 'translateY(' + y + 'px)';
        panels[i].style.backgroundColor = 'rgb(' + v + ',' + v + ',' + v + ')';
      }

      // 左侧步骤：卡 2/3/4 各自收拢到位时点亮下一步
      var step = 0;
      if (progress >= RANGE) step = 3;
      else if (progress >= (RANGE / 3) * 2) step = 2;
      else if (progress >= RANGE / 3) step = 1;
      applyStep(step);
    }

    function onScroll() {
      if (!ticking) {
        ticking = true;
        window.requestAnimationFrame(update);
      }
    }

    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', function () {
      RANGE = sec.offsetHeight - sticky.offsetHeight;
      if (!(RANGE > 0)) RANGE = 972;
      lastStep = -1;
      onScroll();
    });
    update();
    // 字体/图片加载完成后布局可能轻微变化，再校正一次
    window.addEventListener('load', onScroll);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
