/* ============================================================
   SkillHub 复刻 · 云服务客户端封装
   ------------------------------------------------------------
   - 一次性初始化 SDK（endpoint + publishableKey + oauthRelayBaseUrl 均来自 publicConfig）
   - 暴露 auth / database / storage 的常用能力给页面脚本
   - 统一把 SDK 的 { data, error } 结果转成友好文案
   注意：不要在这里手写 fetch('/.cloud/**')，也不要用别的 SDK。
   ============================================================ */
(function () {
  'use strict';

  var config = window.SKILLHUB_PUBLIC_CONFIG || null;
  var clientPromise = null;
  var stateListeners = [];

  function whenSdkReady() {
    return new Promise(function (resolve, reject) {
      var tries = 0;
      (function wait() {
        var WB = window.WorkBuddyCloud;
        if (WB && typeof WB.createWorkBuddyCloud === 'function') {
          resolve(WB);
          return;
        }
        if (++tries > 120) {
          reject(new Error('云服务 SDK 加载失败，请检查网络后刷新页面。'));
          return;
        }
        setTimeout(wait, 60);
      })();
    });
  }

  function getClient() {
    if (!config) return Promise.reject(new Error('缺少云服务配置。'));
    if (!clientPromise) {
      clientPromise = whenSdkReady().then(function (WB) {
        var cloud = WB.createWorkBuddyCloud({
          endpoint: config.endpoint,
          oauthRelayBaseUrl: config.oauthRelayBaseUrl,
          publishableKey: config.publishableKey,
        });
        if (cloud && cloud.auth && typeof cloud.auth.onAuthStateChange === 'function') {
          cloud.auth.onAuthStateChange(function (event, session) {
            stateListeners.forEach(function (fn) {
              try {
                fn(event, session || null);
              } catch (e) {
                /* 单个订阅者出错不影响其它订阅者 */
              }
            });
          });
        }
        return cloud;
      });
    }
    return clientPromise;
  }

  function onChange(fn) {
    if (typeof fn === 'function') stateListeners.push(fn);
    return function () {
      stateListeners = stateListeners.filter(function (f) {
        return f !== fn;
      });
    };
  }

  async function getSession() {
    var cloud = await getClient();
    var res = await cloud.auth.getSession();
    if (res && res.error) return null;
    return (res && res.data) || null;
  }

  function friendlyError(error) {
    if (!error) return '操作失败，请稍后重试。';
    var kind = error.kind || '';
    if (kind === 'network' || kind === 'backend-unavailable') {
      return '网络异常，请检查连接后重试。';
    }
    if (kind === 'unauthenticated' || kind === 'invalid_grant') {
      return '登录状态已失效，请重新登录。';
    }
    if (error.code === '23505') return '该内容已存在，请换个名称。';
    if (error.code === '42501') return '当前账号没有权限执行该操作。';
    if (error.code === '42P01') return '云端数据表尚未就绪，请联系管理员。';
    if (error.status === 429) return '操作过于频繁，请稍后再试。';
    return error.message || '操作失败，请稍后重试。';
  }

  /* ---------------- 登录（手机号验证码 / 微信） ---------------- */

  function sendPhoneCode(phone) {
    return getClient().then(function (cloud) {
      return cloud.auth.sendOtp({ phone: phone });
    });
  }

  function verifyPhoneCode(phone, verificationId, isExistingUser, token) {
    return getClient().then(function (cloud) {
      return cloud.auth.verifyOtp({
        phone: phone,
        verificationId: verificationId,
        isExistingUser: isExistingUser,
        token: token,
      });
    });
  }

  function sendEmailCode(email) {
    return getClient().then(function (cloud) {
      return cloud.auth.sendOtp({ email: email });
    });
  }

  function verifyEmailCode(email, verificationId, isExistingUser, token) {
    return getClient().then(function (cloud) {
      return cloud.auth.verifyOtp({
        email: email,
        verificationId: verificationId,
        isExistingUser: isExistingUser,
        token: token,
      });
    });
  }

  // redirectTo 必须是同站内绝对路径（如 '/admin.html'），缺省回首页
  async function signInWithWeChat(redirectTo) {
    var cloud = await getClient();
    var back = redirectTo && redirectTo.charAt(0) === '/' ? window.location.origin + redirectTo : window.location.origin + '/';
    var res = await cloud.auth.signInWithOAuth({
      provider: 'wechat',
      redirectTo: back,
    });
    if (res && res.error) throw res.error;
    var url = res && res.data && res.data.url;
    if (!url) throw new Error('未能获取微信登录地址。');
    // 必须同标签页跳转：PKCE 校验串存在当前标签页的 sessionStorage
    window.location.assign(url);
  }

  function signOut() {
    return getClient().then(function (cloud) {
      return cloud.auth.signOut();
    });
  }

  /* ---------------- 数据（技能目录 / 用户提交） ---------------- */

  async function listCatalogSkills(limit) {
    var cloud = await getClient();
    var res = await cloud.database
      .from('skills')
      .select('id, slug, name, category, description, icon, author, author_type, downloads, rating, trending')
      .order('downloads', { ascending: false })
      .limit(limit || 12);
    if (res.error) throw res.error;
    return res.data || [];
  }

  async function countCatalogSkills() {
    var cloud = await getClient();
    var res = await cloud.database.from('skills').select('*', { count: 'exact', head: true });
    if (res.error) throw res.error;
    return res.count || 0;
  }

  async function listMySubmissions() {
    var cloud = await getClient();
    var res = await cloud.database
      .from('skill_submissions')
      .select('id, title, summary, category, file_name, file_path, file_size, status, created_at')
      .order('created_at', { ascending: false })
      .limit(50);
    if (res.error) throw res.error;
    return res.data || [];
  }

  async function createSubmission(payload) {
    var cloud = await getClient();
    // 注意：不传 owner_id，由 DEFAULT auth.uid() + RLS 决定归属
    var res = await cloud.database.from('skill_submissions').insert(payload).select();
    if (res.error) throw res.error;
    return (res.data && res.data[0]) || null;
  }

  async function removeSubmission(id) {
    var cloud = await getClient();
    var res = await cloud.database.from('skill_submissions').delete().eq('id', id).select();
    if (res.error) throw res.error;
    return (res.data || []).length > 0;
  }

  /* ---------------- 文件（Skill 包上传） ---------------- */

  async function uploadSkillFile(session, file) {
    var cloud = await getClient();
    var ext = (file.name.split('.').pop() || 'zip').toLowerCase().slice(0, 8);
    var objectPath = cloud.storage.userPath(
      session.user.id,
      'skills/' + Date.now() + '-' + Math.random().toString(36).slice(2, 8) + '.' + ext
    );
    var res = await cloud.storage.upload(objectPath, file, {
      contentType: file.type || 'application/octet-stream',
      upsert: false,
    });
    if (res && res.error) throw res.error;
    // 只回传路径，不外泄签名 URL
    return (res && res.data && (res.data.path || res.data.fullPath)) || objectPath;
  }

  /* ---------------- OAuth 回调（必须早于任何路由守卫） ---------------- */

  async function handleOAuthCallback() {
    var url = new URL(window.location.href);
    if (!url.searchParams.has('code') && !url.searchParams.has('error')) {
      return { handled: false, session: null, error: null };
    }
    var provider = url.searchParams.get('provider');
    if (provider !== 'workbuddy' && provider !== 'wechat') {
      return { handled: true, session: null, error: '授权回调缺少有效的登录方式，请重新登录。' };
    }
    var cloud = await getClient();
    var handler =
      provider === 'workbuddy' ? cloud.auth.handleWorkBuddyCallback : cloud.auth.handleWechatWebCallback;
    if (typeof handler !== 'function') {
      return { handled: true, session: null, error: '当前云服务 SDK 不支持该登录方式。' };
    }
    var res = await handler.call(cloud.auth);
    if (res && res.error) {
      return { handled: true, session: null, error: friendlyError(res.error) };
    }
    var session = res && res.data;
    if (session) {
      for (var i = 0; i < ['code', 'state', 'provider'].length; i++) {
        url.searchParams.delete(['code', 'state', 'provider'][i]);
      }
      history.replaceState(null, '', url.pathname + url.search + url.hash);
    }
    return { handled: true, session: session || null, error: null };
  }

  window.SkillHubCloud = {
    config: config,
    getClient: getClient,
    getSession: getSession,
    onChange: onChange,
    friendlyError: friendlyError,
    sendPhoneCode: sendPhoneCode,
    verifyPhoneCode: verifyPhoneCode,
    sendEmailCode: sendEmailCode,
    verifyEmailCode: verifyEmailCode,
    signInWithWeChat: signInWithWeChat,
    signOut: signOut,
    handleOAuthCallback: handleOAuthCallback,
    listCatalogSkills: listCatalogSkills,
    countCatalogSkills: countCatalogSkills,
    listMySubmissions: listMySubmissions,
    createSubmission: createSubmission,
    removeSubmission: removeSubmission,
    uploadSkillFile: uploadSkillFile,
  };
})();
