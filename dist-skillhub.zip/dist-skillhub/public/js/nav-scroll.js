/* ============================================================
   导航栏滚动态切换（1:1 复刻原站）
   原站实测：scrollY > 20 时 header 的类从
     nav-header-default（background:#ffffffb8，无底边框）
   切换为
     nav-header-scrolled（background:#fffffff0 + 底边框）
   ============================================================ */
(function () {
  'use strict';

  var THRESHOLD = 20;

  function init() {
    var header = document.querySelector('header');
    if (!header) return;

    var last = null;
    function apply() {
      var y = window.scrollY || window.pageYOffset || document.documentElement.scrollTop || 0;
      var scrolled = y > THRESHOLD;
      if (scrolled === last) return;
      last = scrolled;
      header.classList.toggle('nav-header-scrolled', scrolled);
      header.classList.toggle('nav-header-default', !scrolled);
    }

    var ticking = false;
    function onScroll() {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(function () {
        ticking = false;
        apply();
      });
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    apply();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
