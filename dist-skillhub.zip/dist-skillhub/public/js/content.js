/* ============================================================
   SkillHub 前端内容引擎
   从云数据库 site_content 读取站点文案/配置，按 data-ckey 填充页面。
   后台「内容管理」改一处，线上立即生效（无需重新部署）。
   ============================================================ */
(function () {
  'use strict';

  var CACHE_KEY = 'skillhub_content_v1';
  var LS = window.localStorage;

  function getCache() {
    try { return JSON.parse(LS.getItem(CACHE_KEY) || 'null'); } catch (e) { return null; }
  }
  function setCache(data) {
    try {
      LS.setItem(CACHE_KEY, JSON.stringify({
        t: Date.now(),
        map: data && data.map || {},
        skills: (data && data.skills) || null,
      }));
    } catch (e) {}
  }

  // 解析点路径：支持 a.b 与 a.0.b（数组下标）
  function readPath(obj, path) {
    if (!path) return obj;
    var parts = String(path).split('.');
    var cur = obj;
    for (var i = 0; i < parts.length; i++) {
      if (cur == null) return undefined;
      cur = cur[parts[i]];
    }
    return cur;
  }

  /* 数字格式化：898000 -> 89.8 万（与原站一致） */
  function fmtNum(n) {
    var v = Number(n);
    if (!isFinite(v)) return String(n == null ? '' : n);
    if (Math.abs(v) < 10000) return String(v);
    var wan = v / 10000;
    // 保留 1 位小数，与原站 "89.8 万" / "381.5 万" 口径一致
    return (Math.round(wan * 10) / 10).toFixed(1) + ' 万';
  }

  /* 补派生字段：模板可直接用 {{rank}} {{downloadsText}} {{_i}} */
  function decorate(row, i) {
    var r = {};
    for (var k in row) if (Object.prototype.hasOwnProperty.call(row, k)) r[k] = row[k];
    r._i = i;
    r.rank = (i + 1) < 10 ? '0' + (i + 1) : String(i + 1);
    r.downloadsText = fmtNum(row.downloads);
    r.callsText = fmtNum(row.calls);
    return r;
  }

  /* 占位符填充：{{name}} / {{a.b}}，统一转义，避免破坏结构与 XSS */
  function fillTpl(tplHtml, row) {
    return tplHtml.replace(/\{\{\s*([^}]+?)\s*\}\}/g, function (_all, expr) {
      var val = expr === '_i' ? row._i : readPath(row, expr);
      if (val == null) val = '';
      return escapeHtml(String(val));
    });
  }

  /* 列表渲染：容器声明 data-cmode="repeat" + data-ctpl="#id"
     数据源二选一：
       - data-csource="skills"：从 skills 表取，data-clist 指定 trending / hot
       - data-ckey + data-cfield：从 site_content 某键的数组字段取
     拉取失败时保留容器内静态 HTML（兜底），不清空页面。*/
  function applyRepeats(data) {
    var hosts = document.querySelectorAll('[data-cmode="repeat"]');
    for (var hi = 0; hi < hosts.length; hi++) {
      var host = hosts[hi];
      try {
        var rows = null;
        var src = host.getAttribute('data-csource');
        if (src === 'skills') {
          if (!data.skills) continue;                 // 未取到 -> 保留静态兜底
          var kind = host.getAttribute('data-clist') || 'trending';
          var keyf = kind === 'hot' ? 'home_rank_hot' : 'home_rank_trending';
          rows = data.skills.filter(function (r) {
            return Number(r[keyf]) > 0;
          }).sort(function (a, b) { return Number(a[keyf]) - Number(b[keyf]); });
        } else {
          var key = host.getAttribute('data-ckey');
          var fld = host.getAttribute('data-cfield') || '';
          var v = readPath(data.map[key], fld);
          if (!Array.isArray(v)) continue;
          rows = v.slice();
        }
        if (!rows || !rows.length) continue;           // 空结果不动它，避免白屏
        var lim = host.getAttribute('data-climit');
        if (lim) rows = rows.slice(0, parseInt(lim, 10));
        var tplSel = host.getAttribute('data-ctpl');
        var tpl = tplSel ? document.querySelector(tplSel) : null;
        if (!tpl) continue;
        var html = '';
        for (var i = 0; i < rows.length; i++) html += fillTpl(tpl.innerHTML, decorate(rows[i], i));
        host.innerHTML = html;
        hydrateAvatars(host);
      } catch (e) {
        // 单块失败不影响其他区块
        if (window.console) console.error('[content] repeat 渲染失败', host.getAttribute('data-ctpl'), e);
      }
    }
  }

  /* 无图标时的字母头像兜底（与原站 dev-expert 一致：色底 + 首字母） */
  var AV_COLORS = [[52, 199, 89], [57, 87, 255], [255, 149, 0], [175, 82, 222],
    [255, 59, 48], [0, 122, 255], [90, 200, 250], [255, 45, 85], [48, 176, 199]];

  function initialOf(name) {
    var s = String(name == null ? '' : name).trim();
    if (!s) return '?';
    var ch = s.charAt(0);
    return /[a-z]/.test(ch) ? ch.toUpperCase() : ch;
  }

  function avatarColor(name) {
    var s = String(name == null ? '' : name), hh = 0;
    for (var i = 0; i < s.length; i++) hh = (hh * 31 + s.charCodeAt(i)) >>> 0;
    return AV_COLORS[hh % AV_COLORS.length];
  }

  function makeAvatar(img) {
    var name = img.getAttribute('data-cname') || img.getAttribute('alt') || '';
    var cls = String(img.className || '')
      .replace(/\bobject-cover\b/g, '')
      .replace(/\s+/g, ' ')
      .trim();
    var c = avatarColor(name);
    var div = document.createElement('div');
    div.className = cls + ' flex items-center justify-center font-bold';
    div.style.backgroundColor = 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',0.1)';
    div.style.color = 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')';
    div.style.fontSize = /\bw-12\b/.test(cls) ? '18px' : '14px';
    div.setAttribute('aria-hidden', 'true');
    div.textContent = initialOf(name);
    return div;
  }

  /* 图标为空或加载失败时，替换为首字母头像 */
  function hydrateAvatars(scope) {
    var imgs = (scope || document).querySelectorAll('img[data-avatar]');
    for (var i = 0; i < imgs.length; i++) {
      (function (img) {
        var src = (img.getAttribute('src') || '').trim();
        if (!src) {
          if (img.parentNode) img.parentNode.replaceChild(makeAvatar(img), img);
          return;
        }
        img.addEventListener('error', function () {
          if (img.parentNode) img.parentNode.replaceChild(makeAvatar(img), img);
        });
      })(imgs[i]);
    }
  }

  function applyMeta(map) {
    // 子页面可通过 <html data-page-key="p_skills"> 指定自己的内容键，否则用全局 g_meta
    var pageKey = (document.documentElement.getAttribute('data-page-key') || '').trim();
    var metaKey = pageKey || 'g_meta';
    var meta = readPath(map, metaKey) || readPath(map, 'g_meta');
    // seo_title / seo_desc 优先（不覆盖原标题时的独立字段），退回 title / description
    var seoTitle = (meta && meta.seo_title) || (meta && meta.title);
    if (seoTitle) document.title = seoTitle;
    var seoDesc = (meta && meta.seo_desc) || (meta && meta.description);
    if (seoDesc) {
      var m = document.querySelector('meta[name="description"]');
      if (m) m.setAttribute('content', seoDesc);
    }
  }

  function applyDom(map) {
    var nodes = document.querySelectorAll('[data-ckey]');
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      var key = el.getAttribute('data-ckey');
      var field = el.getAttribute('data-cfield') || '';
      var val = readPath(map[key], field);
      if (val == null) continue;

      var mode = el.getAttribute('data-cmode') || (el.hasAttribute('data-chtml') ? 'html' : 'text');
      if (mode === 'repeat') continue;   // 列表容器由 applyRepeats 处理
      if (mode === 'attr') {
        el.setAttribute(el.getAttribute('data-cattr') || 'title', String(val));
      } else if (mode === 'heroTitle') {
        el.setAttribute('aria-label', String(val));
        el.innerHTML = '<span class="inline-flex flex-wrap justify-center">' +
          String(val).split('').map(function (ch) {
            return '<span>' + (ch === ' ' ? '&nbsp;' : escapeHtml(ch)) + '</span>';
          }).join('') + '</span>';
      } else if (mode === 'html') {
        el.innerHTML = sanitizeHtml(String(val));
      } else {
        el.textContent = String(val);
      }
    }
  }

  /* html 字段净化：DOMPurify 可用时净化；缺失时降级为纯文本（绝不直接裸渲染原始串） */
  function sanitizeHtml(s) {
    if (window.DOMPurify && typeof window.DOMPurify.sanitize === 'function') {
      return window.DOMPurify.sanitize(s, { USE_PROFILES: { html: true } });
    }
    // 降级：把字符串当纯文本转义后再写入，语义等同 textContent，杜绝 XSS
    var tmp = document.createElement('div');
    tmp.textContent = s;
    return tmp.innerHTML;
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function applyAll(data) {
    if (!data) return;
    applyMeta(data.map || data);
    applyDom(data.map || data);
    if (data.skills || data.map) applyRepeats(data);
    hydrateAvatars(document);
  }

  function getClient() {
    return window.SkillHubCloud.getClient();
  }

  // 只有页面存在「列表区块」时才拉取 skills 表，避免全站无谓请求
  function needSkills() {
    return document.querySelectorAll('[data-csource="skills"]').length > 0;
  }

  var SKILL_COLS = 'id,slug,name,category,description,icon,author,author_type,downloads,calls,home_rank_trending,home_rank_hot';

  function fetchContent() {
    if (!window.SkillHubCloud) return Promise.reject(new Error('SDK 未就绪'));
    return getClient().then(function (cl) {
      var jobs = [cl.database.from('site_content').select('key, value')];
      if (needSkills()) jobs.push(cl.database.from('skills').select(SKILL_COLS));
      return Promise.all(jobs);
    }).then(function (rs) {
      if (rs[0].error) throw rs[0].error;
      var map = {};
      (rs[0].data || []).forEach(function (r) { map[r.key] = r.value; });
      var skills = null;
      if (rs[1]) {
        if (rs[1].error) throw rs[1].error;
        skills = rs[1].data || [];
      }
      var data = { map: map, skills: skills };
      setCache(data);
      return data;
    });
  }

  var pending = null;
  function refresh() {
    if (pending) return pending;
    pending = fetchContent().then(function (map) {
      applyAll(map);
      return map;
    }).catch(function (e) {
      // 拉取失败：退回到本地静态内容，不打扰用户
      return null;
    }).then(function (m) { pending = null; return m; });
    return pending;
  }

  // 启动：先用缓存秒开，再拉最新
  function boot() {
    if (location.pathname.indexOf('/admin.html') >= 0) return; // 后台页不接管
    var cached = getCache();
    if (cached && cached.map) applyAll(cached);
    refresh();
    // 跨标签页同步：后台保存后前台自动刷新
    window.addEventListener('storage', function (e) {
      if (e.key === CACHE_KEY) refresh();
    });
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) refresh();
    });
  }

  window.SkillHubContent = { refresh: refresh, applyAll: applyAll };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
