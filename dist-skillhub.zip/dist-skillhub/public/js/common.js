/* SkillHub 复刻 — 公共脚本
   负责：API 请求、Toast、模拟登录、注入真实风格导航/页脚、渲染技能卡片。
   视觉类名与原站（Tailwind 编译产物 skillhub.css）完全一致。 */

const API = ''; // 同源部署，直接走 /api

async function api(path, opts = {}) {
  const res = await fetch(API + path, {
    headers: { 'Content-Type': 'application/json' },
    ...opts,
  });
  if (!res.ok) throw new Error('请求失败: ' + res.status);
  return res.json();
}

/* ---------- Toast ---------- */
function toast(msg, type = 'info') {
  let el = document.getElementById('__toast');
  if (!el) {
    el = document.createElement('div');
    el.id = '__toast';
    el.style.cssText =
      'position:fixed;left:50%;bottom:32px;transform:translateX(-50%);z-index:9999;' +
      'background:rgba(28,28,30,.92);color:#fff;padding:10px 18px;border-radius:12px;' +
      'font-size:14px;box-shadow:0 8px 32px rgba(0,0,0,.18);opacity:0;transition:opacity .2s,transform .2s;pointer-events:none';
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.style.opacity = '1';
  el.style.transform = 'translateX(-50%) translateY(0)';
  clearTimeout(el._t);
  el._t = setTimeout(() => {
    el.style.opacity = '0';
    el.style.transform = 'translateX(-50%) translateY(8px)';
  }, 2200);
}

/* ---------- 模拟登录 ---------- */
const USER_KEY = 'skillhub_user';
function getUser() {
  try { return JSON.parse(localStorage.getItem(USER_KEY) || 'null'); } catch { return null; }
}
function setUser(u) { localStorage.setItem(USER_KEY, JSON.stringify(u)); }
function clearUser() { localStorage.removeItem(USER_KEY); }

/* ---------- 导航 / 页脚 ---------- */
const NAV_ITEMS = [
  { label: '首页', href: 'index.html', key: 'home' },
  { label: '技能广场', href: 'skills.html', key: 'skills' },
  { label: '插件广场', href: 'plugins.html', key: 'plugins' },
  { label: '专家包', href: 'packages.html', key: 'packages' },
  { label: '企业专区', href: 'enterprise.html', key: 'enterprise', badge: 'NEW' },
  { label: '教程', href: '#', key: 'tutorials' },
  { label: '关于', href: '#', key: 'about' },
];

const LOGO_SVG =
  '<svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
  '<rect width="34" height="34" rx="9" fill="url(#shg)"/>' +
  '<path d="M11 23V11h8.2c3 0 5 1.9 5 4.8 0 2.9-2 4.8-5 4.8H14v2.4h-3Zm3-4.7h4.8c1.5 0 2.4-.9 2.4-2.3 0-1.4-.9-2.3-2.4-2.3H14v4.6Z" fill="#fff"/>' +
  '<defs><linearGradient id="shg" x1="0" y1="0" x2="34" y2="34" gradientUnits="userSpaceOnUse">' +
  '<stop stop-color="#3957FF"/><stop offset="1" stop-color="#5AC8FA"/></linearGradient></defs></svg>';

function renderNav(activeKey) {
  const root = document.getElementById('nav-root');
  if (!root) return;
  const u = getUser();
  const links = NAV_ITEMS.map((it) => {
    const active = it.key === activeKey ? ' nav-link-active' : '';
    const badge = it.badge
      ? '<span class="nav-new-badge">' + it.badge + '</span>'
      : '';
    return (
      '<a class="nav-link' + active + '" href="' + it.href + '">' +
      '<span class="nav-primary-link-label">' + it.label + badge + '</span></a>'
    );
  }).join('');

  const actions = u
    ? '<a class="nav-link" href="publish.html">发布 Skill</a>' +
      '<span class="nav-link" id="nav-user" style="cursor:pointer">' + escapeHtml(u.nickname || '我') + '</span>'
    : '<a class="nav-link nav-login" href="login.html">登录</a>' +
      '<a class="inline-flex h-10 px-5 rounded-full text-[14px] items-center justify-center bg-primary text-primary-foreground font-medium hover:opacity-90 transition-opacity" href="publish.html">发布 Skill</a>';

  root.className = 'nav-header nav-header-default';
  root.innerHTML =
    '<div class="nav-container">' +
      '<div class="flex items-center gap-2">' +
        '<a class="flex items-center gap-2 no-underline" href="index.html" aria-label="SkillHub 首页">' +
          LOGO_SVG +
          '<span style="font-family:var(--font-heading);font-weight:700;font-size:19px;letter-spacing:-.02em;color:#1c1c1e">SkillHub</span>' +
        '</a>' +
        '<nav class="nav-links flex items-center" style="margin-left:18px">' + links + '</nav>' +
      '</div>' +
      '<div class="nav-actions flex items-center gap-2">' + actions + '</div>' +
    '</div>';

  const nu = document.getElementById('nav-user');
  if (nu) nu.onclick = () => { clearUser(); toast('已退出登录'); location.reload(); };
}

function renderFooter() {
  const root = document.getElementById('footer-root');
  if (!root) return;
  const quick = [
    { label: '技能广场', href: 'skills.html' },
    { label: '插件广场', href: 'plugins.html' },
    { label: '专家包', href: 'packages.html' },
    { label: '企业专区', href: 'enterprise.html' },
    { label: '发布 Skill', href: 'publish.html' },
  ];
  const friend = [
    { label: '腾讯云', href: '#' },
    { label: '混元', href: '#' },
    { label: '微信AI', href: '#' },
    { label: 'Agent 开放平台', href: '#' },
  ];
  root.innerHTML =
    '<footer style="border-top:1px solid rgba(0,0,0,.06);margin-top:48px;background:#fff">' +
      '<div class="page-content-container" style="padding-top:40px;padding-bottom:24px">' +
        '<div class="flex flex-wrap gap-8 md:gap-16">' +
          '<div>' +
            '<h3 class="text-sm font-medium text-black/90 mb-4 tracking-[-.01em]">快捷入口</h3>' +
            '<div class="footer-quick-links flex flex-wrap items-center gap-x-6 gap-y-3">' +
              quick.map((a) => '<a class="inline-flex items-center gap-1 text-sm text-black/50 hover:text-foreground transition-colors duration-250 cursor-pointer no-underline" href="' + a.href + '">' + a.label + '</a>').join('') +
            '</div>' +
          '</div>' +
          '<div>' +
            '<h3 class="text-sm font-medium text-black/90 mb-4 tracking-[-.01em]">友情链接</h3>' +
            '<div class="flex flex-wrap items-center gap-x-6 gap-y-3">' +
              friend.map((a) => '<a class="inline-flex items-center gap-1 text-sm text-black/50 hover:text-foreground transition-colors duration-250 cursor-pointer no-underline" href="' + a.href + '">' + a.label + '</a>').join('') +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div class="border-t border-black/8 py-5">' +
        '<div class="page-content-container flex flex-col md:flex-row md:items-start md:justify-between gap-4">' +
          '<div class="flex flex-col gap-1 md:max-w-[559px]">' +
            '<p class="text-xs text-black/50 leading-[1.5]">来源声明：本站部分 Skill 内容来源于公开渠道、认证企业或由用户自主发布，使用前请注意识别相关风险，内容版权归原作者所有。</p>' +
            '<p class="text-xs text-black/50 leading-[1.67]">侵权处理：如 Skill 涉及版权问题，请发送邮件至 <a href="mailto:skillhub_ipr@tencent.com" class="text-black/50 hover:text-foreground transition-colors duration-250 cursor-pointer">skillhub_ipr@tencent.com</a>，我们将在收到通知后及时核实并予以下架处理。</p>' +
          '</div>' +
          '<div class="flex flex-col gap-1 md:text-right">' +
            '<p class="text-xs text-black/50 leading-[1.67]">Copyright © ' + new Date().getFullYear() + ' SkillHub. 精选 AI Skills 推荐平台</p>' +
            '<p class="text-xs text-[#71717B] leading-[1.67]">技能数据来源于公开渠道、认证企业及用户自主发布。</p>' +
            '<p class="text-xs text-[#71717B] leading-[1.67]"><a href="#" class="text-[#71717B] hover:text-foreground transition-colors duration-250 cursor-pointer">粤B2-20090059-4038</a></p>' +
          '</div>' +
        '</div>' +
      '</div>' +
    '</footer>';
}

/* ---------- 技能卡片（与原站卡片类名一致） ---------- */
function gradientFor(str) {
  const palettes = [
    'linear-gradient(135deg,#007aff,#5ac8fa)',
    'linear-gradient(135deg,#ff9500,#ff6b00)',
    'linear-gradient(135deg,#34c759,#30d158)',
    'linear-gradient(135deg,#af52de,#007aff)',
    'linear-gradient(135deg,#ff2d55,#ff375f)',
    'linear-gradient(135deg,#5e5ce6,#af52de)',
  ];
  let h = 0;
  for (let i = 0; i < (str || '').length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return palettes[h % palettes.length];
}

function skillCard(s) {
  const initial = (s.name || 'S').trim().charAt(0).toUpperCase();
  const tags = (s.tags || '').split(/[,，]/).map((t) => t.trim()).filter(Boolean).slice(0, 3)
    .map((t) => '<span class="inline-flex h-[20px] items-center whitespace-nowrap rounded-[12px] border border-[rgba(0,0,0,0.08)] px-[8px] text-[10px] leading-none text-[rgba(0,0,0,0.4)]">' + escapeHtml(t) + '</span>').join('');
  const cat = CATEGORY_MAP[s.category] || s.category || 'AI Skill';
  return (
    '<a class="group flex h-full flex-col rounded-[12px] border border-[rgba(0,0,0,0.06)] bg-white px-[20px] py-[24px] no-underline transition-all duration-200 hover:border-[rgba(0,0,0,0.12)] hover:shadow-[0_4px_16px_rgba(0,0,0,0.06)]" href="skill.html?id=' + encodeURIComponent(s.id) + '">' +
      '<div class="flex items-center gap-3">' +
        '<div class="w-10 h-10 rounded-[10px] flex items-center justify-center text-white text-[15px] font-semibold shrink-0" style="background:' + gradientFor(s.name) + '">' + escapeHtml(initial) + '</div>' +
        '<div class="min-w-0">' +
          '<div class="text-[15px] font-semibold text-[rgba(0,0,0,0.9)] truncate">' + escapeHtml(s.name) + '</div>' +
          '<div class="text-[12px] text-[rgba(0,0,0,0.4)]">' + escapeHtml(cat) + '</div>' +
        '</div>' +
      '</div>' +
      '<p class="text-[14px] text-[rgba(0,0,0,0.5)] leading-[1.714] mt-2.5 line-clamp-2">' + escapeHtml(s.description || '') + '</p>' +
      '<div class="flex items-center gap-2 mt-3 flex-wrap">' + tags + '</div>' +
      '<div class="border-t border-[rgba(0,0,0,0.06)] mt-4 pt-3 flex items-center justify-between text-[12px] text-[rgba(0,0,0,0.4)]">' +
        '<span>调用 ' + formatNum(s.calls) + '</span>' +
        '<span>收藏 ' + formatNum(s.favorites) + '</span>' +
      '</div>' +
    '</a>'
  );
}

/* ---------- 工具 ---------- */
const CATEGORY_MAP = {
  writing: '写作', efficiency: '效率', coding: '编程',
  design: '设计', analysis: '分析', life: '生活', other: '其他',
};
function formatNum(n) {
  n = Number(n) || 0;
  if (n >= 10000) return (n / 10000).toFixed(1).replace(/\.0$/, '') + 'w';
  if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'k';
  return String(n);
}
function escapeHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function qs(name) {
  return new URLSearchParams(location.search).get(name);
}
