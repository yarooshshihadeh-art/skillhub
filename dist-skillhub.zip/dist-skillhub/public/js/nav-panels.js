/* ============================================================
   导航「技能 / 探索」下拉面板（从 skillhub.cn 原站点击态抓取）
   面板在原站是 React 按需渲染并挂到 body 层的 portal，
   静态快照里没有，这里由 nav-menu.js 注入并使用。
   链接已映射到本站静态页。
   ============================================================ */
window.SKILLHUB_NAV_PANELS = {
  skills:
    '<div id="nav-skills-menu" role="menu" aria-labelledby="nav-skills-trigger" class="nav-mega-menu">' +
    '<div class="nav-mega-menu-content">' +
    '<section class="nav-mega-section" aria-label="技能市场">' +
    '<p class="nav-mega-section-label">技能市场</p>' +
    '<div class="nav-mega-section-items">' +
    '<a role="menuitem" href="/skills.html" class="nav-mega-item"><span class="nav-mega-item-title">全部技能</span><span class="nav-mega-item-description">浏览、搜索所有公开技能</span></a>' +
    '<a role="menuitem" href="/packages.html" class="nav-mega-item"><span class="nav-mega-item-title">专家包</span><span class="nav-mega-item-description">按场景一次安装一组技能</span></a>' +
    '</div></section>' +
    '<section class="nav-mega-section" aria-label="发现技能">' +
    '<p class="nav-mega-section-label">发现技能</p>' +
    '<div class="nav-mega-section-items">' +
    '<a role="menuitem" href="/enterprise.html" class="nav-mega-item"><span class="nav-mega-item-title">企业专区</span><span class="nav-mega-item-description">查看企业发布者与专业技能</span></a>' +
    '</div></section>' +
    '</div></div>',

  explore:
    '<div id="nav-explore-menu" role="menu" aria-labelledby="nav-explore-trigger" class="nav-mega-menu">' +
    '<div class="nav-mega-menu-content">' +
    '<section class="nav-mega-section" aria-label="连接能力">' +
    '<p class="nav-mega-section-label">连接能力</p>' +
    '<div class="nav-mega-section-items">' +
    '<a role="menuitem" href="/mcp.html" class="nav-mega-item"><span class="nav-mega-item-title">MCP 广场</span><span class="nav-mega-item-description">连接工具与服务</span></a>' +
    '</div></section>' +
    '<section class="nav-mega-section" aria-label="角色与表达">' +
    '<p class="nav-mega-section-label">角色与表达</p>' +
    '<div class="nav-mega-section-items">' +
    '<a role="menuitem" href="/soul.html" class="nav-mega-item"><span class="nav-mega-item-title">SOUL 广场</span><span class="nav-mega-item-description">选择人格与表达</span></a>' +
    '</div></section>' +
    '</div></div>',
};
