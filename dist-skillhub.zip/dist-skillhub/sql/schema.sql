-- ============================================================
-- SkillHub 复刻 · 数据库结构（schema）
-- ------------------------------------------------------------
-- 目标库：PostgreSQL（托管平台需提供 PostgREST 风格的 REST 接口与 auth.uid()）
-- 执行顺序：
--   1) 本文件 schema.sql     —— 建表 + 函数 + 权限 + RLS 策略
--   2) seed.sql              —— 导入演示数据（站点文案与技能目录）
--
-- 执行方式：
--   · 托管平台（如 WorkBuddy 云服务）：用平台 SQL 通道逐条执行
--     （多数平台的迁移通道单次只支持一条语句，请按分号拆开执行）
--   · 自建 PostgreSQL：psql -f schema.sql
--
-- 关于 auth.uid()：
--   这是托管平台注入的会话函数（返回当前登录用户 id，字符串）。
--   自建环境请先提供一个同名函数，例如从 JWT 声明里取 sub：
--     CREATE OR REPLACE FUNCTION auth.uid() RETURNS text
--     LANGUAGE sql STABLE AS $$
--       SELECT nullif(current_setting('request.jwt.claim.sub', true), '')
--     $$;
-- ============================================================

-- ============================================================
-- 1. 表结构
-- ============================================================

-- 管理员成员：谁可以进入后台。role 取值 pending / admin / super_admin
CREATE TABLE IF NOT EXISTS public.admin_members (
  id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id      TEXT NOT NULL UNIQUE,
  display_name TEXT,
  role         TEXT NOT NULL DEFAULT 'pending',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE public.admin_members IS '后台管理员名单（pending 为待审批申请）';

-- 技能目录：前台排行榜、技能列表的数据源
CREATE TABLE IF NOT EXISTS public.skills (
  id                 BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  slug               TEXT NOT NULL UNIQUE,          -- 形如 org-xxx/skill-name
  name               TEXT NOT NULL,
  category           TEXT,
  description        TEXT,
  icon               TEXT,                          -- 图片直链或 emoji，可为空（前端用名称首字兜底）
  author             TEXT,
  author_type        TEXT,                          -- personal / enterprise
  downloads          INTEGER DEFAULT 0,
  calls              INTEGER DEFAULT 0,
  rating             NUMERIC DEFAULT 0,
  reviews            INTEGER DEFAULT 0,
  trending           BOOLEAN DEFAULT false,
  featured           BOOLEAN DEFAULT false,
  tags               TEXT[],
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  home_rank_trending INTEGER NOT NULL DEFAULT 0,    -- >0 表示出现在首页「近期飙升」榜，值即排序
  home_rank_hot      INTEGER NOT NULL DEFAULT 0     -- >0 表示出现在首页「下载热榜」，值即排序
);

COMMENT ON TABLE public.skills IS '技能目录（前台只读，后台可写）';

-- 站点内容：CMS 的键值表。value 存内容，schema 存后台表单结构
CREATE TABLE IF NOT EXISTS public.site_content (
  key        TEXT PRIMARY KEY,                      -- 如 g_hero / s_ranking / p_skills
  group_name TEXT NOT NULL DEFAULT 'global',        -- global / sections / pages
  title      TEXT NOT NULL,                         -- 后台里显示的中文名
  schema     JSONB NOT NULL DEFAULT '[]'::jsonb,    -- 字段定义（后台据此生成表单）
  value      JSONB NOT NULL DEFAULT '{}'::jsonb,    -- 实际内容
  updated_by TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE public.site_content IS '站点文案与区块配置（前台按 data-ckey 读取并填充 DOM）';

-- 技能投稿：用户提交待审核的技能包
CREATE TABLE IF NOT EXISTS public.skill_submissions (
  id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  owner_id   TEXT NOT NULL DEFAULT auth.uid(),
  owner_name TEXT,
  title      TEXT NOT NULL,
  summary    TEXT,
  category   TEXT,
  file_path  TEXT,
  file_name  TEXT,
  file_size  BIGINT,
  status     TEXT DEFAULT 'pending',                -- pending / approved / rejected
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE public.skill_submissions IS '技能投稿（投稿人可读写自己的，管理员可读写全部）';

-- 后台操作审计日志
CREATE TABLE IF NOT EXISTS public.admin_audit_log (
  id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  actor_id   TEXT NOT NULL DEFAULT auth.uid(),
  actor_name TEXT,
  action     TEXT NOT NULL,
  target     TEXT,
  target_id  TEXT,
  detail     TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE public.admin_audit_log IS '后台操作审计日志（管理员只能读自己的记录，超管可读全部）';

-- ============================================================
-- 2. 辅助函数
-- ------------------------------------------------------------
-- 为什么必须用 SECURITY DEFINER 函数：
--   RLS 策略里若直接子查询 admin_members 自身，会触发
--   "infinite recursion detected in policy"，Postgres 会直接拒绝。
--   用 SECURITY DEFINER 函数绕过 RLS，才能安全判断「当前用户是不是管理员」。
-- ============================================================

CREATE OR REPLACE FUNCTION public.admin_exists()
  RETURNS boolean
  LANGUAGE sql
  STABLE SECURITY DEFINER
  SET search_path TO 'public'
AS $function$
  SELECT EXISTS (SELECT 1 FROM public.admin_members WHERE role IN ('admin','super_admin'))
$function$;

CREATE OR REPLACE FUNCTION public.is_admin()
  RETURNS boolean
  LANGUAGE sql
  STABLE SECURITY DEFINER
  SET search_path TO 'public'
AS $function$
  SELECT EXISTS (
    SELECT 1 FROM public.admin_members
    WHERE user_id = auth.uid() AND role IN ('admin','super_admin')
  )
$function$;

GRANT EXECUTE ON FUNCTION public.admin_exists() TO authenticated, anon;
GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated, anon;

-- ============================================================
-- 3. 表级权限（第一道门）
-- ------------------------------------------------------------
-- RLS 是两道独立闸门：先要有表级 GRANT，其次才是策略。
-- 漏掉 GRANT 会得到形似「策略失效」的 42501 报错。
-- ============================================================

GRANT SELECT, INSERT                  ON TABLE public.admin_audit_log   TO anon, authenticated;
GRANT SELECT, INSERT                  ON TABLE public.admin_members     TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE  ON TABLE public.site_content      TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE  ON TABLE public.skill_submissions TO anon, authenticated;
GRANT SELECT                          ON TABLE public.skills            TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE          ON TABLE public.skills            TO authenticated;

-- ============================================================
-- 4. 行级安全策略（第二道门）
-- ============================================================

ALTER TABLE public.admin_members     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.skills            ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_content      ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.skill_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_audit_log   ENABLE ROW LEVEL SECURITY;

-- ---------- admin_members ----------
-- 首个登录者可自封超级管理员：仅在系统里一个管理员都没有时允许，
-- 否则新部署的后台会因为「没人能审批第一个管理员」而永久锁死。
DROP POLICY IF EXISTS admin_members_claim_first ON public.admin_members;
CREATE POLICY admin_members_claim_first ON public.admin_members
  FOR INSERT TO anon, authenticated
  WITH CHECK (role = 'super_admin' AND user_id = auth.uid() AND NOT admin_exists());

DROP POLICY IF EXISTS admin_members_request ON public.admin_members;
CREATE POLICY admin_members_request ON public.admin_members
  FOR INSERT TO anon, authenticated
  WITH CHECK (user_id = auth.uid() AND role = 'pending');

DROP POLICY IF EXISTS admin_members_read_own ON public.admin_members;
CREATE POLICY admin_members_read_own ON public.admin_members
  FOR SELECT TO anon, authenticated
  USING (user_id = auth.uid());

DROP POLICY IF EXISTS admin_members_read_all ON public.admin_members;
CREATE POLICY admin_members_read_all ON public.admin_members
  FOR SELECT TO anon, authenticated
  USING (is_admin());

DROP POLICY IF EXISTS admin_members_admin_update ON public.admin_members;
CREATE POLICY admin_members_admin_update ON public.admin_members
  FOR UPDATE TO anon, authenticated
  USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS admin_members_admin_delete ON public.admin_members;
CREATE POLICY admin_members_admin_delete ON public.admin_members
  FOR DELETE TO anon, authenticated
  USING (is_admin());

-- ---------- skills ----------
DROP POLICY IF EXISTS skills_read_all ON public.skills;
CREATE POLICY skills_read_all ON public.skills
  FOR SELECT TO anon, authenticated
  USING (true);

DROP POLICY IF EXISTS skills_admin_insert ON public.skills;
CREATE POLICY skills_admin_insert ON public.skills
  FOR INSERT TO authenticated
  WITH CHECK (is_admin());

DROP POLICY IF EXISTS skills_admin_update ON public.skills;
CREATE POLICY skills_admin_update ON public.skills
  FOR UPDATE TO authenticated
  USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS skills_admin_delete ON public.skills;
CREATE POLICY skills_admin_delete ON public.skills
  FOR DELETE TO authenticated
  USING (is_admin());

-- ---------- site_content ----------
-- 前台匿名可读（站点文案要能被所有人看到），只有管理员能改。
DROP POLICY IF EXISTS site_content_read ON public.site_content;
CREATE POLICY site_content_read ON public.site_content
  FOR SELECT TO anon, authenticated
  USING (true);

DROP POLICY IF EXISTS site_content_write ON public.site_content;
CREATE POLICY site_content_write ON public.site_content
  FOR ALL TO anon, authenticated
  USING (is_admin()) WITH CHECK (is_admin());

-- ---------- skill_submissions ----------
DROP POLICY IF EXISTS skill_submissions_insert_own ON public.skill_submissions;
CREATE POLICY skill_submissions_insert_own ON public.skill_submissions
  FOR INSERT TO anon, authenticated
  WITH CHECK (owner_id = auth.uid());

DROP POLICY IF EXISTS skill_submissions_read_own_or_admin ON public.skill_submissions;
CREATE POLICY skill_submissions_read_own_or_admin ON public.skill_submissions
  FOR SELECT TO anon, authenticated
  USING (owner_id = auth.uid() OR is_admin());

DROP POLICY IF EXISTS skill_submissions_update_own_or_admin ON public.skill_submissions;
CREATE POLICY skill_submissions_update_own_or_admin ON public.skill_submissions
  FOR UPDATE TO anon, authenticated
  USING (owner_id = auth.uid() OR is_admin())
  WITH CHECK (owner_id = auth.uid() OR is_admin());

DROP POLICY IF EXISTS skill_submissions_delete_own ON public.skill_submissions;
CREATE POLICY skill_submissions_delete_own ON public.skill_submissions
  FOR DELETE TO anon, authenticated
  USING (owner_id = auth.uid());

DROP POLICY IF EXISTS skill_submissions_delete_admin ON public.skill_submissions;
CREATE POLICY skill_submissions_delete_admin ON public.skill_submissions
  FOR DELETE TO anon, authenticated
  USING (is_admin());

-- ---------- admin_audit_log ----------
-- 只能读自己产生的记录，超管/管理员可读全部；写入时必须真的是管理员。
DROP POLICY IF EXISTS admin_audit_read ON public.admin_audit_log;
CREATE POLICY admin_audit_read ON public.admin_audit_log
  FOR SELECT TO anon, authenticated
  USING (actor_id = auth.uid() OR is_admin());

DROP POLICY IF EXISTS admin_audit_insert ON public.admin_audit_log;
CREATE POLICY admin_audit_insert ON public.admin_audit_log
  FOR INSERT TO anon, authenticated
  WITH CHECK (actor_id = auth.uid() AND is_admin());
